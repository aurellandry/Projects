//
//  main.cpp
//  minesweeper
//
//  Created by Aurel Landry KENGNI NKONGTCHOU on 27/01/2018.
//  Copyright © 2018 Aurel Landry KENGNI NKONGTCHOU. All rights reserved.
//

#include <cstdlib>
#include <stdlib.h>
#include <iostream>
#include <string>
#include <random>
using namespace std;

//const int mine = 10;
//const int vide = 9;
int lignes = 0;
int colonnes = 0;
//int **plateauDeJeu;


void AfficherContenu(int x, int y, int **plateau);
void InitPlateau (int x, int y, int **plateau);
void PlacerLesMines (int x, int y, int **plateau);
int DansLimitesPlateau(int x, int y, int n, int p);
int mines_voisines(int n, int p, int **plateau, int x, int y);
int jouer_coup(int x, int y, int n, int p, int **plateau, int **liste);
void InitAfficher(int n, int p, int **plateau, int **afficher);
void AfficherPlateauJeu(int n, int p, int **plateau, int **afficherCase);
void CheckAround(int x, int y, int **plateau, int n, int p);


int main(int argc, const char * argv[]) {
    
    cout << "Hello World !" << endl;
    
    cout << "Combien de lignes souhaitez-vous pour le plateau de jeu ? : ";
    cin >> lignes;
    
    cout << "Combien de colonnes souhaitez-vous pour le plateau de jeu ?: ";
    cin >> colonnes;
    
    int **plateauDeJeu;
    int **afficher;
    
    
    plateauDeJeu = new int*[lignes];
    for(unsigned int i=0; i<lignes; i++)
    {
        plateauDeJeu[i]= new int[colonnes];
    }
    
    afficher = new int*[lignes];
    for(unsigned int i=0; i<colonnes; i++)
    {
        afficher[i]= new int[colonnes];
    }
    

    
    InitPlateau(lignes, colonnes, plateauDeJeu);
    PlacerLesMines(lignes, colonnes, plateauDeJeu);
    InitAfficher(lignes, colonnes, plateauDeJeu, afficher);
    AfficherPlateauJeu(lignes, colonnes, plateauDeJeu, afficher);
    
    
    int x, y;
    
    cout << "Entrez l'abscisse de la case de votre choix : ";
    cin >> x;
    
    cout << "Entrez l'ordonnée de la case de votre choix : ";
    cin >> y;
    
    while (DansLimitesPlateau(x, y, lignes, colonnes) == 0)
    {
        cout << "Entrez l'abscisse de la case de votre choix : ";
        cin >> x;
        
        cout << "Entrez l'ordonnée de la case de votre choix : ";
        cin >> y;
    }
    
/* ===================================================================================
 *
 *                                     DÉBUT DU JEU
 *
 * ================================================================================== */
    
    while (jouer_coup(x, y, lignes, colonnes, plateauDeJeu, afficher) == 1)
    {
        
        AfficherPlateauJeu(lignes, colonnes, plateauDeJeu, afficher);
        
        cout << "Entrez l'abscisse de la case de votre choix : ";
        cin >> x;
        
        cout << "Entrez l'ordonnée de la case de votre choix : ";
        cin >> y;
        
        while (DansLimitesPlateau(x, y, lignes, colonnes) == 0)
        {
            cout << "Entrez l'abscisse de la case de votre choix : ";
            cin >> x;
            
            cout << "Entrez l'ordonnée de la case de votre choix : ";
            cin >> y;
        }
        
    }
    
    AfficherContenu(lignes, colonnes, plateauDeJeu);
    
    return 0;
}

/* ====================================================================================
 *
 *                                  FIN DU MAIN
 *
 * =================================================================================== */

void AfficherContenu(int n, int p, int **plateau)
{
    
    for (int i = 0; i < n; i++)
    {
        cout << "\n";
        for (int j = 0; j < p; j++)
        {
            if (plateau[i][j] == 10)
            {
                cout << "[X]";
            }
            
            else if (plateau[i][j] == 0)
            {
                cout << "[-]";
            }
            
            else
            {
                cout << "[" << plateau[i][j] << "]";
            }
            
        }
        
    }
    
    cout << "\n";
}

void InitPlateau (int x, int y, int **plateau)
{
    for (int i = 0; i < x; i++)
    {
        for (int j = 0; j < y; j++)
        {
            plateau[i][j] = 9;
        }
    }
}

void PlacerLesMines (int x, int y, int **plateau)
{
    
    int nombreMines;
    
    cout << "Combien de mines souhaitez vous dissimuler ? : ";
    cin >> nombreMines;
    
    while (nombreMines >= x*y)
    {
        cout << "Le nombre de mines ne peut pas être supérieur ou égal au nombre de cases du tableau." << endl;
        cout << "Combien de mines souhaitez vous dissimuler ? : ";
        cin >> nombreMines;
    }
    
    for (int i = 0; i < nombreMines; i++)
    {
        int abs = rand() % (x) + 0;
        int ord = rand() % (y) + 0;
        
        while (plateau[abs][ord] == 10)
        {
            abs = rand() % (x) + 0;
            ord = rand() % (y) + 0;
        }
        
        plateau[abs][ord] = 10;
    }
}

int DansLimitesPlateau(int x, int y, int n, int p)
{
    if ((x > 0 && x < n+1) || (y > 0 && y < p+1))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

int mines_voisines(int n, int p, int **plateau, int x, int y)
{
    int nbrMinesVoisines = 0;
    
    if (plateau[x][y] == 10) {
        return 10;
    }
    
// ===================== Cas de la 1ère ligne ====================================
    
    if (x == 0)
    {
        
        if (y == 0)
        {
            if ((plateau)[x][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
        }
        
        if (y == p-1)
        {
            if (plateau[x][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
        }
        
        if (y > 0 and y < p-1)
        {
            if (plateau[x][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
        }
        
    }
   
// ================== Fin Cas de la 1ère ligne =========================================
    
// ================== Cas de la dernière ligne =========================================
    
    if (x == n - 1)
    {
        
        if (y == 0)
        {
            if (plateau[x][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x-1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x-1][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
        }
        
        if (y == p-1)
        {
            if (plateau[x][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x-1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x-1][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
        }
        
        if (y > 0 and y < p-1)
        {
            if (plateau[x][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x-1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x-1][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x-1][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
        }
        
    }
    
// =================== Fin Cas de la dernière ligne =================================
    
// =================== Début Cas du milieu ==========================================
    
    if (x > 0 and x < n-1)
    {
        
        if (y == 0)
        {
            if (plateau[x-1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x-1][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
        }
        
        if (y == p-1)
        {
            if (plateau[x-1][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x-1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
        }
        
        if (y > 0 and y < p-1)
        {
            if (plateau[x-1][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x-1][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x-1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y-1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y+1] == 10)
            {
                nbrMinesVoisines += 1;
            }
            
            if (plateau[x+1][y] == 10)
            {
                nbrMinesVoisines += 1;
            }
        }
        
    }

// ========================== Fin Cas du milieu ===========================================
    
    return nbrMinesVoisines;
}

int jouer_coup(int x, int y, int n, int p, int **plateau, int **liste)
{
    if (plateau[x-1][y-1] == 10)
    {
        cout << "\nPerdu !" << endl;
        return 0;
    }
    else
    {
        int z = mines_voisines(n, p, plateau, x-1, y-1);
        plateau[x-1][y-1] = z;
        CheckAround(x-1, y-1, plateau, n, p);
        return 1;
    }
}


void InitAfficher(int n, int p, int **plateau, int **afficherCase)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < p; j++)
        {
            if (plateau[i][j] == 9 or plateau[i][j] == 10)
            {
                afficherCase[i][j] = 0;
            }
            else
            {
                afficherCase[i][j] = 1;
            }
            
            //cout << afficherCase[i][j] << endl;
        }
    }
}


void AfficherPlateauJeu(int n, int p, int **plateau, int **afficherCase)
{
    
    for (int i = 0; i < n; i++)
    {
        cout << "\n";
        
        for (int j = 0; j < p; j++)
        {
            //afficherCase = afficher(i, j, plateau);
            if (plateau[i][j] == 9 or plateau[i][j] == 10)
            {
                cout << "[ ]";
            }
            
            else if (plateau[i][j] == 0)
            {
                cout << "[-]";
            }
            
            else
            {
                cout << "[" << plateau[i][j] << "]";
            }
        }
    }
    
    cout << "\n";
}

void CheckAround(int x, int y, int **plateau, int n, int p)
{
    
    if (plateau[x][y+1] == 9) {
        if (x == 0)
        {
            
            if (y == 0)
            {
                if (plateau[x][y+1] == 9)
                {
                    plateau[x][y+1] = 0;
                }
                
                if (plateau[x+1][y] == 9)
                {
                    plateau[x+1][y] = 0;
                }
                
                if (plateau[x+1][y+1] == 9)
                {
                    plateau[x+1][y+1] = 0;
                }
            }
            
            if (y == p-1)
            {
                if (plateau[x][y-1] == 9)
                {
                    plateau[x][y-1] = 0;
                }
                
                if (plateau[x+1][y] == 9)
                {
                    plateau[x+1][y] = 0;
                }
                
                if (plateau[x+1][y-1] == 9)
                {
                    plateau[x+1][y-1] = 0;
                }
            }
            
            if (y > 0 and y < p-1)
            {
                if (plateau[x][y-1] == 9)
                {
                    plateau[x][y-1] = 0;
                }
                
                if (plateau[x][y+1] == 9)
                {
                    plateau[x][y+1] = 0;
                }
                
                if (plateau[x+1][y] == 9)
                {
                    plateau[x+1][y] = 0;
                }
                
                if (plateau[x+1][y-1] == 9)
                {
                    plateau[x+1][y-1] = 0;
                }
                
                if (plateau[x+1][y+1] == 9)
                {
                    plateau[x+1][y+1] = 0;
                }
            }
            
        }
        
        // ================== Fin Cas de la 1ère ligne =========================================
        
        // ================== Cas de la dernière ligne =========================================
        
        if (x == n - 1)
        {
            
            if (y == 0)
            {
                if (plateau[x][y+1] == 9)
                {
                    plateau[x][y+1] = 0;
                }
                
                if (plateau[x-1][y] == 9)
                {
                    plateau[x-1][y] = 0;
                }
                
                if (plateau[x-1][y+1] == 9)
                {
                    plateau[x-1][y+1] = 0;
                }
            }
            
            if (y == p-1)
            {
                if (plateau[x][y-1] == 9)
                {
                    plateau[x][y-1] = 0;
                }
                
                if (plateau[x-1][y] == 9)
                {
                    plateau[x-1][y] = 0;
                }
                
                if (plateau[x-1][y-1] == 9)
                {
                    plateau[x-1][y-1] = 0;
                }
            }
            
            if (y > 0 and y < p-1)
            {
                if (plateau[x][y-1] == 9)
                {
                    plateau[x][y-1] = 0;
                }
                
                if (plateau[x][y+1] == 9)
                {
                    plateau[x][y+1] = 0;
                }
                
                if (plateau[x-1][y] == 9)
                {
                    plateau[x-1][y] = 0;
                }
                
                if (plateau[x-1][y-1] == 9)
                {
                    plateau[x-1][y-1] = 0;
                }
                
                if (plateau[x-1][y+1] == 9)
                {
                    plateau[x-1][y+1] = 0;
                }
            }
            
        }
        
        // =================== Fin Cas de la dernière ligne =================================
        
        // =================== Début Cas du milieu ==========================================
        
        if (x > 0 and x < n-1)
        {
            
            if (y == 0)
            {
                if (plateau[x-1][y] == 9)
                {
                    plateau[x-1][y] = 0;
                }
                
                if (plateau[x-1][y+1] == 9)
                {
                    plateau[x-1][y+1] = 0;
                }
                
                if (plateau[x][y+1] == 9)
                {
                    plateau[x][y+1] = 0;
                }
                
                if (plateau[x+1][y+1] == 9)
                {
                    plateau[x+1][y+1] = 0;
                }
                
                if (plateau[x+1][y] == 9)
                {
                    plateau[x+1][y] = 0;
                }
            }
            
            if (y == p-1)
            {
                if (plateau[x-1][y-1] == 9)
                {
                    plateau[x-1][y-1] = 0;
                }
                
                if (plateau[x-1][y] == 9)
                {
                    plateau[x-1][y] = 0;
                }
                
                if (plateau[x][y-1] == 9)
                {
                    plateau[x][y-1] = 0;
                }
                
                if (plateau[x+1][y-1] == 9)
                {
                    plateau[x+1][y-1] = 0;
                }
                
                if (plateau[x+1][y] == 9)
                {
                    plateau[x+1][y] = 0;
                }
            }
            
            if (y > 0 and y < p-1)
            {
                if (plateau[x-1][y-1] == 9)
                {
                    plateau[x-1][y-1] = 0;
                }
                
                if (plateau[x-1][y+1] == 9)
                {
                    plateau[x-1][y+1] = 0;
                }
                
                if (plateau[x-1][y] == 9)
                {
                    plateau[x-1][y] = 0;
                }
                
                if (plateau[x][y-1] == 9)
                {
                    plateau[x][y-1] = 0;
                }
                
                if (plateau[x][y+1] == 9)
                {
                    plateau[x][y+1] = 0;
                }
                
                if (plateau[x+1][y-1] == 9)
                {
                    plateau[x+1][y-1] = 0;
                }
                
                if (plateau[x+1][y+1] == 9)
                {
                    plateau[x+1][y+1] = 0;
                }
                
                if (plateau[x+1][y] == 9)
                {
                    plateau[x+1][y] = 0;
                }
            }
        }
        
    }
    
}
