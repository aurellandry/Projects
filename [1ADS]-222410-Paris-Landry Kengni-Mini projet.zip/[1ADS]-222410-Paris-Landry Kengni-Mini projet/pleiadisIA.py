from random import randint

def newBoard(n):
    board = [[]]*n

    for a in range(n):
        lst = [0]*n
        board[a] = lst

    return board

def display(board, n):

    print("-"*((2*n)+1))

    for a in range(n):
        s = "|"
        for b in range(n):
            if board[a][b] == 0:
                s += ".|"
            if board[a][b] == 1:
                s += "x|"
            if board[a][b] == 2:
                s += "o|"
            if board[a][b] == 3:
                s += ".|"
            if board[a][b] == 4:
                s += ".|"
            if board[a][b] == 7:
                s += ".|"

        print(s)
        print("-"*((2*n)+1))

def selectSquare(board, n, player):

    i = int(input("Entrez la ligne sur laquelle vous voulez poser votre pion : "))
    while i > n or i < 1:
        i = int(input("Entrez la ligne sur laquelle vous voulez poser votre pion : "))

    j = int(input("Entrez la colonne sur laquelle vous voulez poser votre pion : "))
    while j > n or j < 1:
        j = int(input("Entrez la colonne sur laquelle vous voulez poser votre pion : "))

    if player == 0:
        while board[i-1][j-1] == 1 or board[i-1][j-1] == 2 or board[i-1][j-1] == 4 or i > n or i < 1 or j > n or j < 1:
            i = int(input("Entrez la ligne sur laquelle vous voulez poser votre pion : "))
            j = int(input("Entrez la colonne sur laquelle vous voulez poser votre pion : "))

    if player == 1:
        while board[i-1][j-1] == 1 or board[i-1][j-1] == 2 or board[i-1][j-1] == 3 or i > n or i < 1 or j > n or j < 1:
            i = int(input("Entrez la ligne sur laquelle vous voulez poser votre pion : "))
            j = int(input("Entrez la colonne sur laquelle vous voulez poser votre pion : "))

    return i, j

def selectSquareIA2(board, n, player):                       #L'IA joue, par ordre de priorité les cases vides, les cases neutres (contrôlées par les deux joueurs) et les cases qu'elle contrôle
    nbr0 = 0
    nbr7 = 0

    for a in range(n):
        nbr0 += board[a].count(0)
        nbr7 += board[a].count(7)

    if nbr0 >= nbr7 and nbr0 > 0:
        i, j = randint(0, n-1), randint(0, n-1)
        while board[i][j] != 0:
            i, j = randint(0, n-1), randint(0, n-1)

    elif nbr7 > nbr0:
        i, j = randint(0, n-1), randint(0, n-1)
        while board[i][j] != 7:
            i, j = randint(0, n-1), randint(0, n-1)

    elif nbr7 == 0:
        i, j = randint(0, n-1), randint(0, n-1)
        while board[i][j] != 3:
            i, j = randint(0, n-1), randint(0, n-1)

    return i, j

def selectSquareIA1(board, n, player):                          #L'IA joue, par ordre de priorité les cases vides, les cases neutres (contrôlées par les deux joueurs) et les cases qu'elle contrôle
    a = (n+1)//2 - 1
    b = (n+1)//2 - 1
    nbr0 = 0
    nbr7 = 0

    if board[a][b] != 1 and board[a][b] != 2 and board[a][b] != 3:
        i = a
        j = b
    else:
        for a in range(n):
            nbr0 += board[a].count(0)
            nbr7 += board[a].count(7)

        if nbr0 >= nbr7 and nbr0 > 0:                       
            i, j = randint(0, n-1), randint(0, n-1)
            while board[i][j] != 0:
                i, j = randint(0, n-1), randint(0, n-1)

        elif nbr7 > nbr0:
            i, j = randint(0, n-1), randint(0, n-1)
            while board[i][j] != 7:
                i, j = randint(0, n-1), randint(0, n-1)

        elif nbr7 == 0:
            i, j = randint(0, n-1), randint(0, n-1)
            while board[i][j] != 4:
                i, j = randint(0, n-1), randint(0, n-1)

    return i, j

def update2(board, i, j, n, player):                                      #Dans le cas où l'IA commence le jeu, l'update se déroule ainsi.

    if player == 0:
        board[i][j] = 1
        if i-1 >= 0 and board[i-1][j] != 1 and board[i-1][j] != 2 and board[i-1][j] != 3:
            if board[i-1][j] == 7:
                board[i-1][j] = 3
            else:
                board[i-1][j] += 3

        if i+1 < n and board[i+1][j] != 1 and board[i+1][j] != 2 and board[i+1][j] != 3 :
            if board[i+1][j] == 7:
                board[i+1][j] = 3
            else:
                board[i+1][j] += 3

        if j-1 >= 0 and board[i][j-1] != 1 and board[i][j-1] != 2 and board[i][j-1] != 3:
            if board[i][j-1] == 7:
                board[i][j-1] = 3
            else:
                board[i][j-1] += 3

        if j+1 < n and board[i][j+1] != 1 and board[i][j+1] != 2 and board[i][j+1] != 3:
            if board[i][j+1] == 7:
                board[i][j+1] = 3
            else:
                board[i][j+1] += 3

        if i-1 >= 0 and j-1 >= 0 and board[i-1][j-1] != 1 and board[i-1][j-1] != 2 and board[i-1][j-1] != 3:
            if board[i-1][j-1] == 7:
                board[i-1][j-1] = 3
            else:
                board[i-1][j-1] += 3

        if i-1 >= 0 and j+1 < n and board[i-1][j+1] != 1 and board[i-1][j+1] != 2 and board[i-1][j+1] != 3:
            if board[i-1][j+1] == 7:
                board[i-1][j+1] = 3
            else:
                board[i-1][j+1] += 3

        if i+1 < n and j-1 >= 0 and board[i+1][j-1] != 1 and board[i+1][j-1] != 2 and board[i+1][j-1] != 3:
            if board[i+1][j-1] == 7:
                board[i+1][j-1] = 3
            else:
                board[i+1][j-1] += 3

        if i+1 < n and j+1 < n and board[i+1][j+1] != 1 and board[i+1][j+1] != 2 and board[i+1][j+1] != 3:
            if board[i+1][j+1] == 7:
                board[i+1][j+1] = 3
            else:
                board[i+1][j+1] += 3

    if player == 1:
        i -= 1
        j -= 1
        board[i][j] = 2
        if i-1 >= 0 and board[i-1][j] != 1 and board[i-1][j] != 2 and board[i-1][j] != 4:
            if board[i-1][j] == 7:
                board[i-1][j] = 4
            else:
                board[i-1][j] += 4

        if i+1 < n and board[i+1][j] != 1 and board[i+1][j] != 2 and board[i+1][j] != 4:
            if board[i+1][j] == 7:
                board[i+1][j] = 4
            else:
                board[i+1][j] += 4

        if j-1 >= 0 and board[i][j-1] != 1 and board[i][j-1] != 2 and board[i][j-1] != 4:
            if board[i][j-1] == 7:
                board[i][j-1] = 4
            else:
                board[i][j-1] += 4

        if j+1 < n and board[i][j+1] != 1 and board[i][j+1] != 2 and board[i][j+1] != 4:
            if board[i][j+1] == 7:
                board[i][j+1] = 4
            else:
                board[i][j+1] += 4

        if i-1 >= 0 and j-1 >= 0 and board[i-1][j-1] != 1 and board[i-1][j-1] != 2 and board[i-1][j-1] != 4:
            if board[i-1][j-1] == 7:
                board[i-1][j-1] = 4
            else:
                board[i-1][j-1] += 4

        if i-1 >= 0 and j+1 < n and board[i-1][j+1] != 1 and board[i-1][j+1] != 2 and board[i-1][j+1] != 4:
            if board[i-1][j+1] == 7:
                board[i-1][j+1] = 4
            else:
                board[i-1][j+1] += 4

        if i+1 < n and j-1 >= 0 and board[i+1][j-1] != 1 and board[i+1][j-1] != 2 and board[i+1][j-1] != 4:
            if board[i+1][j-1] == 7:
                board[i+1][j-1] = 4
            else:
                board[i+1][j-1] += 4

        if i+1 < n and j+1 < n and board[i+1][j+1] != 1 and board[i+1][j+1] != 2 and board[i+1][j+1] != 4:
            if board[i+1][j+1] == 7:
                board[i+1][j+1] = 4
            else:
                board[i+1][j+1] += 4


def update1(board, i, j, n, player):                                      #Dans le cas où l'humain commence le jeu, l'update se déroule de cette manière.

    if player == 0:
        i -= 1
        j -= 1
        board[i][j] = 1
        if i-1 >= 0 and board[i-1][j] != 1 and board[i-1][j] != 2 and board[i-1][j] != 3:
            if board[i-1][j] == 7:
                board[i-1][j] = 3
            else:
                board[i-1][j] += 3

        if i+1 < n and board[i+1][j] != 1 and board[i+1][j] != 2 and board[i+1][j] != 3 :
            if board[i+1][j] == 7:
                board[i+1][j] = 3
            else:
                board[i+1][j] += 3

        if j-1 >= 0 and board[i][j-1] != 1 and board[i][j-1] != 2 and board[i][j-1] != 3:
            if board[i][j-1] == 7:
                board[i][j-1] = 3
            else:
                board[i][j-1] += 3

        if j+1 < n and board[i][j+1] != 1 and board[i][j+1] != 2 and board[i][j+1] != 3:
            if board[i][j+1] == 7:
                board[i][j+1] = 3
            else:
                board[i][j+1] += 3

        if i-1 >= 0 and j-1 >= 0 and board[i-1][j-1] != 1 and board[i-1][j-1] != 2 and board[i-1][j-1] != 3:
            if board[i-1][j-1] == 7:
                board[i-1][j-1] = 3
            else:
                board[i-1][j-1] += 3

        if i-1 >= 0 and j+1 < n and board[i-1][j+1] != 1 and board[i-1][j+1] != 2 and board[i-1][j+1] != 3:
            if board[i-1][j+1] == 7:
                board[i-1][j+1] = 3
            else:
                board[i-1][j+1] += 3

        if i+1 < n and j-1 >= 0 and board[i+1][j-1] != 1 and board[i+1][j-1] != 2 and board[i+1][j-1] != 3:
            if board[i+1][j-1] == 7:
                board[i+1][j-1] = 3
            else:
                board[i+1][j-1] += 3

        if i+1 < n and j+1 < n and board[i+1][j+1] != 1 and board[i+1][j+1] != 2 and board[i+1][j+1] != 3:
            if board[i+1][j+1] == 7:
                board[i+1][j+1] = 3
            else:
                board[i+1][j+1] += 3

    if player == 1:
        board[i][j] = 2
        if i-1 >= 0 and board[i-1][j] != 1 and board[i-1][j] != 2 and board[i-1][j] != 4:
            if board[i-1][j] == 7:
                board[i-1][j] = 4
            else:
                board[i-1][j] += 4

        if i+1 < n and board[i+1][j] != 1 and board[i+1][j] != 2 and board[i+1][j] != 4:
            if board[i+1][j] == 7:
                board[i+1][j] = 4
            else:
                board[i+1][j] += 4

        if j-1 >= 0 and board[i][j-1] != 1 and board[i][j-1] != 2 and board[i][j-1] != 4:
            if board[i][j-1] == 7:
                board[i][j-1] = 4
            else:
                board[i][j-1] += 4

        if j+1 < n and board[i][j+1] != 1 and board[i][j+1] != 2 and board[i][j+1] != 4:
            if board[i][j+1] == 7:
                board[i][j+1] = 4
            else:
                board[i][j+1] += 4

        if i-1 >= 0 and j-1 >= 0 and board[i-1][j-1] != 1 and board[i-1][j-1] != 2 and board[i-1][j-1] != 4:
            if board[i-1][j-1] == 7:
                board[i-1][j-1] = 4
            else:
                board[i-1][j-1] += 4

        if i-1 >= 0 and j+1 < n and board[i-1][j+1] != 1 and board[i-1][j+1] != 2 and board[i-1][j+1] != 4:
            if board[i-1][j+1] == 7:
                board[i-1][j+1] = 4
            else:
                board[i-1][j+1] += 4

        if i+1 < n and j-1 >= 0 and board[i+1][j-1] != 1 and board[i+1][j-1] != 2 and board[i+1][j-1] != 4:
            if board[i+1][j-1] == 7:
                board[i+1][j-1] = 4
            else:
                board[i+1][j-1] += 4

        if i+1 < n and j+1 < n and board[i+1][j+1] != 1 and board[i+1][j+1] != 2 and board[i+1][j+1] != 4:
            if board[i+1][j+1] == 7:
                board[i+1][j+1] = 4
            else:
                board[i+1][j+1] += 4


def change_player(player):
    if player == 0:
        player += 1
    else:
        player -= 1

    return player

def notFinish(board, player, n):
    s0 = 0
    s3 = 0
    s4 = 0
    s7 = 0
    if_continue = True
    
    for a in range(n):
        s0 += board[a].count(0)
        s3 += board[a].count(3)
        s4 += board[a].count(4)
        s7 += board[a].count(7)

    if s0 == 0 and s7 == 0 and (s3 == 0 or s4 == 0):
        if_continue = False

    return if_continue

def pleiadisIA(n, beginner):

    if beginner == 2:
        
        board = newBoard(n)
        display(board, n)
        x, y = ((n+1)//2 - 1) , ((n+1)//2 - 1)
        player = 0
        update2(board, x, y, n, player)
        print("\nIA :\n")
        display(board, n)
        player = 1
        finish = True

        while finish == True :
        
            if player == 1:
                print("\nHumain:\n")
                x, y = selectSquare(board, n, player)

            if player == 0:
                print("\nIA")
                x, y =selectSquareIA2(board, n, player)

            update2(board, x, y, n, player)
            display(board, n)
            finish = notFinish(board, player, n)
            player = change_player(player)

        if player == 1:
            print("Gagnant : Humain")
        else:
            print("Gagnant: IA")

    if beginner == 1:

        board = newBoard(n)
        display(board, n)
        print("\nConseil: Commencez par jouer au centre du tableau, ensuite s'il y a plus de cases vides que de cases neutres jouez dans les cases vides. \nSinon jouez dans les cases neutres. S'il n'y en a plus, jouez dans les cases que vous contrôlez.\n")
        player = 0
        finish = notFinish(board, player, n)

        while finish == True:

            if player == 0:
                print("\nJoueur", player+1,":\n")
                x, y = selectSquare(board, n, player)

            if player == 1:
                print("\nIA")
                x, y =selectSquareIA1(board, n, player)

            update1(board, x, y, n, player)
            display(board, n)
            finish = notFinish(board, player, n)
            player = change_player(player)

        if player == 0:
            print("Gagnant : Joueur", player+1)
        else:
            print("Gagnant : IA")

#By Landry Kengni (id: 222410)
