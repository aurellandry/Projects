from firstattack2 import *

def newBoard(n):
    board = [[]] * n

    for i in range(n) :
        board[i] = [0]*n

    return board

def display(board, n):
    print("-"*((2*n)+1))
    for i in range(n):
        a = "|"
        for j in range(n):
            if board[i][j] == 0:
                a += ".|"
            if board[i][j] == 1:
                a += "o|"
            if board[i][j] == 2:
                a += ".|"

        print(a)
        print("-"*((2*n)+1))

def update(board, n, i, j):
    i -= 1
    j -= 1
    
    board[i] = [2]*n
    for a in range(n):
        if a != i:
            board[a][j] = 2
        continue

    for k in range(n):
        if i-k >= 0 and j-k >= 0:
            board[i-k][j-k] = 2
        if i-k >= 0 and j+k < n:
            board[i-k][j+k] = 2
        if i+k < n and j-k >= 0:
            board[i+k][j-k] = 2
        if i+k < n and j+k < n:
            board[i+k][j+k] = 2
            
    board[i][j] = 1

def checkCol(board, j, n):
    lst = []
    for a in range(n):
        lst.append(board[a][j-1])
    return lst

def checkAround(board, i, j, n):

    lst_col = checkCol(board, j, n)
    
    if board[i-1].count(1) != 0:
        print("Un pion occupe déjà cette ligne. Veuillez jouer ailleurs !")

    elif 1 in lst_col:
        print("Un pion occupe déjà cette colonne. Veuillez jouer ailleurs !")

    else:
        print("Un pion occupe déjà une diagonale passant par cette position. Veuillez jouer ailleurs !")

def selectSquare(board, n):
    
    i = int(input("Choisissez la ligne où poser votre pion : "))
    while i > n and i < 1 :
        i = int(input("Choisissez la ligne où poser votre pion : "))
    
    j = int(input("Choisissez la colonne où poser votre pion : "))
    while j > n and j < 1 :
        j = int(input("Choisissez la colonne où poser votre pion : "))

    while board[i-1][j-1] != 0 :

        if board[i-1][j-1] == 1:
            print("Cette case est occupée. Veuillez jouer ailleurs !")
        else:
            checkAround(board, i, j, n)
        
        i = int(input("Choisissez la ligne où poser votre pion : "))
        while i > n and i < 1 :
            i = int(input("Choisissez la ligne où poser votre pion : "))
    
        j = int(input("Choisissez la colonne où poser votre pion : "))
        while j > n and j < 1 :
            j = int(input("Choisissez la colonne où poser votre pion : "))

    return i, j

def notFinish(board, n):
    if_finish = False
    empty_case = 0
    for a in range(n):
        empty_case += board[a].count(0)
    if empty_case > 0:
        if_finish = True

    return if_finish

def change_player(player):
    if player == 0 :
        player +=1
    else :
        player -= 1
    return player

def firstAttack(n):
    board = newBoard(n)
    display(board, n)
    finish = notFinish(board, n)
    player = 0

    while finish == True :
        print("\nJoueur", player+1,":\n")
        x, y = selectSquare(board, n)
        update(board, n, x, y)
        display(board, n)
        finish = notFinish(board, n)
        player = change_player(player)

    player = change_player(player)
    print("Gagnant : Joueur", player+1)


m = int(input("\nVoulez-vous jouer avec des pions identiques (1) ou avec des pions différents (2) ? : "))
while m != 1 and m != 2:
    m = int(input("\nVoulez-vous jouer avec des pions identiques (1) ou avec des pions différents (2) ? : "))


n = int(input("Entrez le nombre de lignes et de colonnes du tableau : "))
while n < 2:
    n = int(input("Entrez le nombre de lignes et de colonnes du tableau : "))

if m == 1:
    firstAttack(n)
else:
    firstAttack2(n)

#By Landry Kengni (id: 222410)
