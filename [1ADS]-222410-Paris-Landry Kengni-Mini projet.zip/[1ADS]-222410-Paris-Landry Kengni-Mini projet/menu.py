import time

jouer = 1

while jouer == 1 :
    print("Bienvenue sur notre menu de mini-jeux. Ici, vous avez le choix entre 3 mini-jeux et pour chacun d'entre-eux, nous essaierons de vous en présenter les règles.\n")

    jeu = int(input("1- Breaktrough \n2- First Attack \n3- Pleiadis \n4- Quitter \nA quel jeu voulez-vous jouer ? (Entrez le numéro du jeu) : "))
    while jeu != 1 and jeu != 2 and jeu != 3 and jeu != 4 :
        jeu = int(input("1- Breaktrough \n2- First Attack \n3- Pleiadis \n4- Quitter \nA quel jeu voulez-vous jouer ? (Entrez le numéro du jeu) : "))

    if jeu == 1 :
        print("\nDans ce jeu, chaque jouer joue à tour de rôle, en commençant par les blancs (représentés par des 'x') \net ensuite les noirs (représentés par des 'o'). Chaque pion peut se déplacer d'une ligne, en diagonale \nou verticalement. Il est important de noter qu'un pion ne peut pas se déplacer verticalement lorsqu'il \na un pion adverse qui lui barre le chemin. Le jeu se termine lorsque l'un des joueurs arrive à poser un pion à l'autre bout du \ntableau ou bien lorsque tous les pions d'un joueur ont été bouffés par l'adversaire.")
        time.sleep(1)
        replay = 1
        while replay == 1:
            from breaktrough import *
            time.sleep(1)
            replay = int(input("1- Rejouer \n2- Quitter \nQue choisissez-vous ? : "))
            print("")

            if replay == 1 :
                m = int(input("Joueur 1 vs Joueur 2 (1) ou Joueur 1 vs IA (2) ? : "))

                while m != 1 and m !=2 :
                    m = int(input("Joueur 1 vs Joueur 2 (1) ou Joueur 1 vs IA (2) ? : "))

                n = int(input("Entrez le nombre de lignes du tableau : "))

                while n < 4 :
                    print("Le tableau doit avoir au moins 5 lignes !")
                    n = int(input("Entrez le nombre de lignes du tableau : "))

                p = int(input("Entrez le nombre de colonnes du tableau : "))

                while p <= 1 :
                    print("Le tableau doit avoir au moins 2 colonnes !") 
                    p = int(input("Entrez le nombre de colonnes du tableau : ")) 

                print("")
                if m == 1:
                    breaktrough(n, p)
                else :
                    breaktroughIA(n, p)
    
    elif jeu == 2 :
        print("\nA tour de rôle les joueurs posent un pion sur une case vide du plateau de telle sorte que cette case ne soit pas sur la \nmême ligne, la même colonne ou la même diagonale qu’un pion déjà présent sur le plateau. \nLe gagnant est le dernier joueur à pouvoir poser un pion. Autrement dit, dès qu’un joueur ne peut plus poser de pion il a perdu.")
        time.sleep(1)
        replay = 1
        while replay == 1:
            from firstattack import *
            time.sleep(1)
            replay = int(input("1- Rejouer \n2- Quitter \nQue choisissez-vous ? : "))
            print("")

            if replay == 1 :
                n = int(input("Entrez le nombre de lignes et de colonnes du tableau : "))
                while n < 2 :
                    n = int(input("Entrez le nombre de lignes et de colonnes du tableau : "))

                print("")
                firstAttack(n)

    elif jeu == 3 :
        print("\nLes 'x' commencent, puis à tour de rôle les joueurs posent un de leurs pions sur une case vide du plateau de telle sorte que pour cette case \nle nombre de pions adjacents de l’adversaire (orthogonalement ou en diagonale) présents sur le plateau soit inférieur \nou égal au nombre de pions adjacents du joueur. Le gagnant est le dernier joueur à pouvoir poser un pion. Autrement dit, dès qu’un joueur \nne peut plus poser de pion il a perdu.")
        time.sleep(1)
        replay = 1
        while replay == 1:
            from pleiadis import *
            time.sleep(1)
            replay = int(input("1- Rejouer \n2- Quitter \nQue choisissez-vous ? : "))
            print("")

            if replay == 1 :
                version = int(input("\nJouez-vous contre un adversaire humain (1) ou contre l'IA (2) ? : "))

                if version == 1:
                    n = int(input("Entrez le nombre de lignes du tableau : "))
                    pleiadis(n)
                else:
                    n = int(input("Entrez un nombre impair de lignes pour le tableau : "))
                    while n%2 == 0:
                        n = int(input("Entrez un nombre impair de lignes pour le tableau : "))

                    beginner = int(input("\n1- Vous commencez. \n2- L'IA commence. \nQue choisissez-vous ? : "))
                    while beginner != 1 and beginner != 2:
                        beginner = int(input("\n1- Vous commencez. \n2- L'IA commence. \nQue choisissez-vous ? : "))
        
                    pleiadisIA(n, beginner)

    elif jeu == 4 :
        break

#By Landry Kengni (id: 222410)
