def newBoard(n):
    board = [[]] * n

    for i in range(n) :
        board[i] = [0]*n

    return board

def display2(board, n):
    print("-"*((2*n)+1))
    for i in range(n):
        a = "|"
        for j in range(n):
            if board[i][j] == 0:
                a += ".|"
            if board[i][j] == 1:
                a += "x|"
            if board[i][j] == 2:
                a += "o|"
            if board[i][j] == 3:
                a += ".|"
            if board[i][j] == 4:
                a += ".|"
            if board[i][j] == 7:
                a += ".|"

        print(a)
        print("-"*((2*n)+1))

def update2(board, i, j, player, n):
    i -= 1
    j -= 1

    if player == 0:
        board[i][j] = 1
        for a in range(n):
            if board[i][a] != 1 and board[i][a] != 2 and board[i][a] != 3 and board[i][a] != 7:
                board[i][a] += 3

            if board[a][j] != 1 and board[a][j] != 2 and board[a][j] != 3 and board[a][j] != 7:
                board[a][j] += 3

            if i-a >= 0 and j-a >= 0 and board[i-a][j-a] != 1 and board[i-a][j-a] != 2 and board[i-a][j-a] != 3 and board[i-a][j-a] != 7:
                board[i-a][j-a] += 3

            if i-a >= 0 and j+a < n and board[i-a][j+a] != 1 and board[i-a][j+a] != 2 and board[i-a][j+a] != 3 and board[i-a][j+a] != 7:
                board[i-a][j+a] +=3

            if i+a < n and j-a >= 0 and board[i+a][j-a] != 1 and board[i+a][j-a] != 2 and board[i+a][j-a] != 3 and board[i+a][j-a] != 7:
                board[i+a][j-a] += 3

            if i+a < n and j+a < n and board[i+a][j+a] != 1 and board[i+a][j+a] != 2 and board[i+a][j+a] != 3 and board[i+a][j+a] != 7:
                board[i+a][j+a] += 3

    if player == 1:
        board[i][j] = 2
        for a in range(n):
            if board[i][a] != 1 and board[i][a] != 2 and board[i][a] != 4 and board[i][a] != 7:
                board[i][a] += 4

            if board[a][j] != 1 and board[a][j] != 2 and board[a][j] != 4 and board[a][j] != 7:
                board[a][j] += 4

            if i-a >= 0 and j-a >= 0 and board[i-a][j-a] != 1 and board[i-a][j-a] != 2 and board[i-a][j-a] != 4 and board[i-a][j-a] != 7:
                board[i-a][j-a] += 4

            if i-a >= 0 and j+a < n and board[i-a][j+a] != 1 and board[i-a][j+a] != 2 and board[i-a][j+a] != 4 and board[i-a][j+a] != 7:
                board[i-a][j+a] +=4

            if i+a < n and j-a >= 0 and board[i+a][j-a] != 1 and board[i+a][j-a] != 2 and board[i+a][j-a] != 4 and board[i+a][j-a] != 7:
                board[i+a][j-a] += 4

            if i+a < n and j+a < n and board[i+a][j+a] != 1 and board[i+a][j+a] != 2 and board[i+a][j+a] != 4 and board[i+a][j+a] != 7:
                board[i+a][j+a] += 4

def checkCol(board, j, n):
    lst = []
    for a in range(n):
        lst.append(board[a][j-1])
    return lst

def checkAround(board, i, j, n, player):

    lst_col = checkCol(board, j, n)

    if player == 0:
        if board[i-1].count(1) != 0:
            print("Un pion occupe déjà cette ligne. Veuillez jouer ailleurs !")

        elif 1 in lst_col:
            print("Un pion occupe déjà cette colonne. Veuillez jouer ailleurs !")

        else:
            print("Un pion occupe déjà une diagonale passant par cette position. Veuillez jouer ailleurs !")

    if player == 1:
        if board[i-1].count(2) != 0:
            print("Un pion occupe déjà cette ligne. Veuillez jouer ailleurs !")

        elif 2 in lst_col:
            print("Un pion occupe déjà cette colonne. Veuillez jouer ailleurs !")

        else:
            print("Un pion occupe déjà une diagonale passant par cette position. Veuillez jouer ailleurs !")
                
def selectSquare(board, n):
    
    i = int(input("Choisissez la ligne où poser votre pion : "))
    while i < 1 and i > n :
        i = int(input("Choisissez la ligne où poser votre pion : "))
    
    j = int(input("Choisissez la colonne où poser votre pion : "))
    while j < 1 and j > n :
        j = int(input("Choisissez la colonne où poser votre pion : "))

    return i, j

def selectSquare2(board, n, player):

    v = 0
    
    i, j = selectSquare(board, n)
    
    if player == 0:
        while board[i-1][j-1] == 1 or board[i-1][j-1] == 2 or board[i-1][j-1] == 3 or board[i-1][j-1] == 7:
            if board[i-1][j-1] == 1 or board[i-1][j-1] == 2:
                print("Cette case est occupée. Veuillez jouer ailleurs !")
            else:
                checkAround(board, i, j, n, player)
            i, j = selectSquare(board, n)

    if player == 1:
        while board[i-1][j-1] == 1 or board[i-1][j-1] == 2 or board[i-1][j-1] == 4 or board[i-1][j-1] == 7:
            if board[i-1][j-1] == 1 or board[i-1][j-1] == 2:
                print("Cette case est déjà occupée. Veuillez jouer ailleurs !")
            else:
                checkAround(board, i, j, n, player)
            i, j = selectSquare(board, n)
    
    return i, j

def notFinish(board, player, n):
    s0 = 0
    s3 = 0
    s4 = 0
    if_continue = True
    
    for a in range(n):
        s0 += board[a].count(0)
        s3 += board[a].count(3)
        s4 += board[a].count(4)

    if s0 == 0 and (s3 == 0 or s4 == 0):
        if_continue = False

    return if_continue

def change_player(player):
    if player == 0 :
        player +=1
    else :
        player -= 1
    return player

def firstAttack2(n):
    board = newBoard(n)
    display2(board, n)
    player = 0
    finish = True

    while finish == True :
        print("\nJoueur", player+1,":\n")
        x, y = selectSquare2(board, n, player)
        update2(board, x, y, player, n)    
        display2(board, n)
        finish = notFinish(board, player, n)
        player = change_player(player)

    print("Gagnant : Joueur", player+1, "car l'adversaire ne pourra plus poser de pion.")

#By Landry Kengni (id: 222410)
