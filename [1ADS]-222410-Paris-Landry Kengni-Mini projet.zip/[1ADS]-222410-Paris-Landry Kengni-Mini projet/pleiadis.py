from pleiadisIA import *

def newBoard(n):
    board = [[]]*n

    for a in range(n):
        lst = [0]*n
        board[a] = lst

    return board

def display(board, n):

    print("-"*((2*n)+1))

    for a in range(n):
        s = "|"
        for b in range(n):
            if board[a][b] == 0:
                s += ".|"
            if board[a][b] == 1:
                s += "x|"
            if board[a][b] == 2:
                s += "o|"
            if board[a][b] == 3:
                s += "3|"
            if board[a][b] == 4:
                s += "4|"
            if board[a][b] == 7:
                s += "7|"

        print(s)
        print("-"*((2*n)+1))

def selectSquare(board, n, player):

    i = int(input("Entrez la ligne sur laquelle vous voulez poser votre pion : "))
    while i > n or i < 1:
        i = int(input("Entrez la ligne sur laquelle vous voulez poser votre pion : "))

    j = int(input("Entrez la colonne sur laquelle vous voulez poser votre pion : "))
    while j > n or j < 1:
        j = int(input("Entrez la colonne sur laquelle vous voulez poser votre pion : "))

    if player == 0:
        while board[i-1][j-1] == 1 or board[i-1][j-1] == 2 or board[i-1][j-1] == 4 or i > n or i < 1 or j > n or j < 1:
            i = int(input("Entrez la ligne sur laquelle vous voulez poser votre pion : "))
            j = int(input("Entrez la colonne sur laquelle vous voulez poser votre pion : "))

    if player == 1:
        while board[i-1][j-1] == 1 or board[i-1][j-1] == 2 or board[i-1][j-1] == 3 or i > n or i < 1 or j > n or j < 1:
            i = int(input("Entrez la ligne sur laquelle vous voulez poser votre pion : "))
            j = int(input("Entrez la colonne sur laquelle vous voulez poser votre pion : "))

    return i, j

def update(board, i, j, n, player):
    i -= 1
    j -= 1

    if player == 0:
        board[i][j] = 1
        if i-1 >= 0 and board[i-1][j] != 1 and board[i-1][j] != 2 and board[i-1][j] != 3:
            if board[i-1][j] == 7:
                board[i-1][j] = 3
            else:
                board[i-1][j] += 3

        if i+1 < n and board[i+1][j] != 1 and board[i+1][j] != 2 and board[i+1][j] != 3 :
            if board[i+1][j] == 7:
                board[i+1][j] = 3
            else:
                board[i+1][j] += 3

        if j-1 >= 0 and board[i][j-1] != 1 and board[i][j-1] != 2 and board[i][j-1] != 3:
            if board[i][j-1] == 7:
                board[i][j-1] = 3
            else:
                board[i][j-1] += 3

        if j+1 < n and board[i][j+1] != 1 and board[i][j+1] != 2 and board[i][j+1] != 3:
            if board[i][j+1] == 7:
                board[i][j+1] = 3
            else:
                board[i][j+1] += 3

        if i-1 >= 0 and j-1 >= 0 and board[i-1][j-1] != 1 and board[i-1][j-1] != 2 and board[i-1][j-1] != 3:
            if board[i-1][j-1] == 7:
                board[i-1][j-1] = 3
            else:
                board[i-1][j-1] += 3

        if i-1 >= 0 and j+1 < n and board[i-1][j+1] != 1 and board[i-1][j+1] != 2 and board[i-1][j+1] != 3:
            if board[i-1][j+1] == 7:
                board[i-1][j+1] = 3
            else:
                board[i-1][j+1] += 3

        if i+1 < n and j-1 >= 0 and board[i+1][j-1] != 1 and board[i+1][j-1] != 2 and board[i+1][j-1] != 3:
            if board[i+1][j-1] == 7:
                board[i+1][j-1] = 3
            else:
                board[i+1][j-1] += 3

        if i+1 < n and j+1 < n and board[i+1][j+1] != 1 and board[i+1][j+1] != 2 and board[i+1][j+1] != 3:
            if board[i+1][j+1] == 7:
                board[i+1][j+1] = 3
            else:
                board[i+1][j+1] += 3

    if player == 1:
        board[i][j] = 2
        if i-1 >= 0 and board[i-1][j] != 1 and board[i-1][j] != 2 and board[i-1][j] != 4:
            if board[i-1][j] == 7:
                board[i-1][j] = 4
            else:
                board[i-1][j] += 4

        if i+1 < n and board[i+1][j] != 1 and board[i+1][j] != 2 and board[i+1][j] != 4:
            if board[i+1][j] == 7:
                board[i+1][j] = 4
            else:
                board[i+1][j] += 4

        if j-1 >= 0 and board[i][j-1] != 1 and board[i][j-1] != 2 and board[i][j-1] != 4:
            if board[i][j-1] == 7:
                board[i][j-1] = 4
            else:
                board[i][j-1] += 4

        if j+1 < n and board[i][j+1] != 1 and board[i][j+1] != 2 and board[i][j+1] != 4:
            if board[i][j+1] == 7:
                board[i][j+1] = 4
            else:
                board[i][j+1] += 4

        if i-1 >= 0 and j-1 >= 0 and board[i-1][j-1] != 1 and board[i-1][j-1] != 2 and board[i-1][j-1] != 4:
            if board[i-1][j-1] == 7:
                board[i-1][j-1] = 4
            else:
                board[i-1][j-1] += 4

        if i-1 >= 0 and j+1 < n and board[i-1][j+1] != 1 and board[i-1][j+1] != 2 and board[i-1][j+1] != 4:
            if board[i-1][j+1] == 7:
                board[i-1][j+1] = 4
            else:
                board[i-1][j+1] += 4

        if i+1 < n and j-1 >= 0 and board[i+1][j-1] != 1 and board[i+1][j-1] != 2 and board[i+1][j-1] != 4:
            if board[i+1][j-1] == 7:
                board[i+1][j-1] = 4
            else:
                board[i+1][j-1] += 4

        if i+1 < n and j+1 < n and board[i+1][j+1] != 1 and board[i+1][j+1] != 2 and board[i+1][j+1] != 4:
            if board[i+1][j+1] == 7:
                board[i+1][j+1] = 4
            else:
                board[i+1][j+1] += 4


def change_player(player):
    if player == 0:
        player += 1
    else:
        player -= 1

    return player

def checkAround(board, i, j, n, player):
    lst = []
    
    if i == 1 and j == 1:
        lst.append(board[i-1][j])
        lst.append(board[i][j])
        lst.append(board[i][j-1])

    if i == 1 and j == n:
        lst.append(board[i-1][j-2])
        lst.append(board[i][j-2])
        lst.append(board[i][j-1])

    if i == n and j == 1:
        lst.append(board[i-1][j])
        lst.append(board[i-2][j])
        lst.append(board[i-2][j-1])

    if i == n and j == n:
        lst.append(board[i-1][j-2])
        lst.append(board[i-2][j-2])
        lst.append(board[i-2][j-1])

    if i == 1 and j > 1 and j < n:
        lst.append(board[i-1][j-2])
        lst.append(board[i-1][j])
        lst.append(board[i][j-2])
        lst.append(board[i][j-1])
        lst.append(board[i][j])

    if i == n and j > 1 and j < n:
        lst.append(board[i-1][j-2])
        lst.append(board[i-1][j])
        lst.append(board[i-2][j-2])
        lst.append(board[i-2][j-1])
        lst.append(board[i-2][j])

    if j == 1 and i > 1 and i < n:
        lst.append(board[i-2][j-1])
        lst.append(board[i-2][j])
        lst.append(board[i-1][j])
        lst.append(board[i][j])
        lst.append(board[i][j-1])

    if j == n and i > 1 and i < n:
        lst.append(board[i-2][j-1])
        lst.append(board[i-2][j-2])
        lst.append(board[i-1][j-2])
        lst.append(board[i][j-2])
        lst.append(board[i][j-1])

    if i > 1 and i < n and j > 1 and j < n:
        lst.append(board[i-2][j-2])
        lst.append(board[i-2][j-1])
        lst.append(board[i-2][j])
        lst.append(board[i-1][j-2])
        lst.append(board[i-1][j])
        lst.append(board[i][j-2])
        lst.append(board[i][j-1])
        lst.append(board[i][j])

def notFinish(board, player, n):
    s0 = 0
    s3 = 0
    s4 = 0
    s7 = 0
    if_continue = True
    
    for a in range(n):
        s0 += board[a].count(0)
        s3 += board[a].count(3)
        s4 += board[a].count(4)
        s7 += board[a].count(7)

    if s0 == 0 and s7 == 0 and (s3 == 0 or s4 == 0):
        if_continue = False

    return if_continue

def pleiadis(n):
    board = newBoard(n)
    display(board, n)
    player = 0
    finish = True

    while finish == True :
        print("\nJoueur", player+1,":\n")
        x, y = selectSquare(board, n, player)
        update(board, x, y, n, player)    
        display(board, n)
        finish = notFinish(board, player, n)
        player = change_player(player)

    print("Gagnant : Joueur", player+1)

version = int(input("\nJouez-vous contre un adversaire humain (1) ou contre l'IA (2) ? : "))

if version == 1:
    n = int(input("Entrez le nombre de lignes du tableau : "))
    pleiadis(n)
else:
    n = int(input("Entrez un nombre impair de lignes pour le tableau : "))
    while n%2 == 0:
        n = int(input("Entrez un nombre impair de lignes pour le tableau : "))

    beginner = int(input("\n1- Vous commencez. \n2- L'IA commence. \nQue choisissez-vous ? : "))
    while beginner != 1 and beginner != 2:
        beginner = int(input("\n1- Vous commencez. \n2- L'IA commence. \nQue choisissez-vous ? : "))
        
    pleiadisIA(n, beginner)

#By Landry Kengni (id: 222410)
