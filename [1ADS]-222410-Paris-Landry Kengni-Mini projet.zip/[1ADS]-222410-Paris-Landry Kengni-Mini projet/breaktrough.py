from random import randint

def newBoard(n,p):
        board = [[]] * n

        print(board)

        for i in range (2):
                lst = []
                for j in range (p): 
                        lst.append(1)
                board[i]=lst

        print(board)

        for i in range (2, n-2):
                lst = []
                for j in range (p):
                        lst.append(0)
                board[i]=lst

        print(board)

        for i in range (n-2, n):
                lst = []
                for j in range (p):
                        lst.append(2)
                board[i]=lst

        print(board)
        return board
    
def display(board, n, p):
        i = 0
        j = 0
        print("-"*((2*p)+1))
        while i < n :
                a = "|"
                while j < p :
                        if board[i][j] == 1 :
                                a += "x|"
                        if board[i][j] == 0 :
                                a += ".|"
                        if board[i][j] == 2 :
                                a += "o|"
                        j += 1
                j = 0
                print(a)
                print("-"*((2*p)+1))
                i += 1

def selectPawn(board, n, p, player):
        i = int(input("Entrez la ligne du pion à déplacer : "))
        while i > n :
                i = int(input("Entrez la ligne du pion à déplacer : "))
                
        j = int(input("Entrez la colonne du pion à déplacer : "))
        while j > p :
                j = int(input("Entrez la colonne du pion à déplacer : "))

        while board[i-1][j-1] == 0 :
                print("Vous ne pouvez pas sélectionner une case vide.")
                i = int(input("Entrez la ligne du pion à déplacer : "))
                while i > n :
                        i = int(input("Entrez la ligne du pion à déplacer : "))
                j = int(input("Entrez la colonne du pion à déplacer : "))
                while j > p :
                        j = int(input("Entrez la colonne du pion à déplacer : "))

        while player == 0 and (board[i-1][j-1] == 2 or board[i-1][j-1] == 0) :

                if board[i-1][j-1] == 0:
                        print("Vous ne pouvez pas sélectionner une case vide.")
                else:        
                        print("Vous ne pouvez pas sélectionner un pion adverse.")
                         
                i = int(input("Entrez la ligne du pion à déplacer : "))
                while i > n :
                        i = int(input("Entrez la ligne du pion à déplacer : "))
                j = int(input("Entrez la colonne du pion à déplacer : "))
                while j > p :
                        j = int(input("Entrez la colonne du pion à déplacer : "))

        while player == 1 and (board[i-1][j-1] == 1 or board[i-1][j-1] == 0) :

                if board[i-1][j-1] == 0:
                        print("Vous ne pouvez pas sélectionner une case vide.")
                else:        
                        print("Vous ne pouvez pas sélectionner un pion adverse.")
                         
                i = int(input("Entrez la ligne du pion à déplacer : "))
                while i > n :
                        i = int(input("Entrez la ligne du pion à déplacer : "))
                j = int(input("Entrez la colonne du pion à déplacer : "))
                while j > p :
                        j = int(input("Entrez la colonne du pion à déplacer : "))

        return i, j

def change_player(player):
        if player == 0 :
                player +=1
        else :
                player -= 1
        return player

def where(board, n, p, player, i, j):
        a = 0
        if player == 0 :
                b = int(input("Choisissez la colonne de destination du pion : "))
                if i < n :
                        a = i + 1
                while (b == j) and (board[a-1][b-1] == 2) :
                        print("Vous ne pouvez pas jouer là.")
                        b = int(input("Choisissez la colonne de destination du pion : "))
                while (b > p) or (b < 1) or (b > j+1) or (b < j-1) or (board[a-1][b-1] == 1) :
                        print("Vous ne pouvez pas jouer là.")
                        b = int(input("Choisissez la colonne de destination du pion : "))

        if player == 1 :
                b = int(input("Choisissez la colonne de destination du pion : "))

                if i > 1 :
                        a = i - 1
                while (b == j) and (board[a-1][b-1] == 1) :
                        print("Vous ne pouvez pas jouer là.")
                        b = int(input("Choisissez la colonne de destination du pion : "))
                while (board[a-1][b-1] == 2) or (b > p) or (b < 1) or (b > j+1) or (b < j-1) :
                        b = int(input("Choisissez la colonne de destination du pion : "))
                        
        return a, b

def selectPawnIA(board, n, p, player):
        i = randint(2, n)
        j = randint(1, p)

        while board[i-1][j-1] == 0 or board[i-1].count(2) == 0 :
                i = randint(2, n)
                j = randint(1, p)

        while board[i-1][j-1] == 1 or board[i-1].count(2) == 0:
                i = randint(2, n)
                j = randint(1, p)

                while board[i-1][j-1] == 0 or board[i-1].count(2) == 0 :
                        i = randint(2, n)
                        j = randint(1, p)

        if j > 1 and j < p:
            while (board[i-2][j-2] == 2) and (board[i-2][j] == 2) and (board[i-2][j-1] != 0) :
                i = randint(2, n)
                j = randint(1, p)

                while board[i-1][j-1] == 0 or board[i-1].count(2) == 0 :
                        i = randint(2, n)
                        j = randint(2, p-1)

        if j == 1:
            while (board[i-2][j] == 2) and (board[i-2][j-1] == 1) :
                i = randint(2, n)
                j = randint(1, p)

                while board[i-1][j-1] == 0 or board[i-1].count(2) == 0 :
                        i = randint(2, n)
                        j = randint(1, p)

        if j == p:
            while (board[i-2][j-2] == 2) and (board[i-2][j-1] == 1) :
                i = randint(1, n)
                j = randint(1, p)

                while board[i-1][j-1] == 0 or board[i-1].count(2) == 0 :
                        i = randint(2, n)
                        j = randint(1, p)

        return i, j

def whereIA(board, n, p, player, i, j):
        a = 0        
        b = randint(1, p)

        if i > 1 :
                a = i - 1
        while (b == j) and (board[a-1][b-1] == 1) :
                i, j = selectPawnIA(board, n, p, player)
                a = i - 1
                b = randint(1, p)
        while (board[a-1][b-1] == 2) or (b > p) or (b < 1) or (b > j+1) or (b < j-1) :
                i, j = selectPawnIA(board, n, p, player)
                a = i - 1
                b = randint(1, p)
                while (b == j) and (board[a-1][b-1] == 1) :
                        i, j = selectPawnIA(board, n, p, player)
                        a = i - 1
                        b = randint(1, p)
                        
        return a, b, i, j

def winner(board, nbr_pawn1, nbr_pawn2):
        i = 0
        j = 0

        nbr_pawn1 = 0
        nbr_pawn2 = 0
        for i in range(n):
                nbr_pawn1 += board[i].count(1)
        for i in range(n):
                nbr_pawn2 += board[i].count(2)

        if nbr_pawn1 == 0 :
                print("Gagnant : Joueur 2")
        if nbr_pawn2 == 0 :
                print("Gagnant : Joueur 1")
                
        while i < 1 :
                while j < p :
                        if board[i][j] == 2 :
                                print("Gagnant : Joueur 2")
                        j += 1
                i += 1
        
        i = n-1
        j = 0
        while i < n :
                while j < p :
                        if board[i][j] == 1 :
                                print("Gagnant : Joueur 1")
                        j += 1
                i += 1


def winnerIA(board, nbr_pawn1, nbr_pawn2):
        i = 0
        j = 0

        nbr_pawn1 = 0
        nbr_pawn2 = 0
        for i in range(n):
                nbr_pawn1 += board[i].count(1)
        for i in range(n):
                nbr_pawn2 += board[i].count(2)

        if nbr_pawn1 == 0 :
                print("Gagnant : IA")
        if nbr_pawn2 == 0 :
                print("Gagnant : Joueur 1")
                
        while i < 1 :
                while j < p :
                        if board[i][j] == 2 :
                                print("Gagnant : IA")
                        j += 1
                i += 1
        
        i = n-1
        j = 0
        while i < n :
                while j < p :
                        if board[i][j] == 1 :
                                print("Gagnant : Joueur 1")
                        j += 1
                i += 1

def breaktroughIA(n, p):
        board = newBoard(n, p)
        display(board, n, p)
        print("")
        nbr_pawn1 = 0
        nbr_pawn2 = 0
        for i in range(n):
                nbr_pawn1 += board[i].count(1)
        for i in range(n):
                nbr_pawn2 += board[i].count(2)
        player = 0
        i = 0
        s = 2
        
        while board[0].count(2) == 0  and board[n-1].count(1) == 0 and nbr_pawn1 != 0 and nbr_pawn2 != 0:
                if player == 0:
                        print("Joueur", player+1, ":")
                        x, y = selectPawn(board, n, p, player)

                        if y > 1 and y < p and x < n:
                                while board[x][y-2] == 1 and board[x][y-1] != 0 and board[x][y] == 1:
                                        print("Selon les règles du jeu, ce pion ne peut pas se déplacer. Veuillez en choisir un autre .")
                                        x, y = selectPawn(board, n, p, player)

                        if y == 1 and x < n:
                                while board[x][y-1] != 0 and board[x][y] == 1:
                                        print("Selon les règles du jeu, ce pion ne peut pas se déplacer. Veuillez en choisir un autre .")
                                        x, y = selectPawn(board, n, p, player)

                        if y == p and x < n:
                                while board[x][y-2] == 1 and board[x][y-1] != 0:
                                        print("Selon les règles du jeu, ce pion ne peut pas se déplacer. Veuillez en choisir un autre .")
                                        x, y = selectPawn(board, n, p, player)
                        
                        a, b = where(board, n, p, player, x, y)
                        
                        board[a-1][b-1] = 1
                        board[x-1][y-1] = 0

                        for i in range(n):
                                nbr_pawn1 += board[i].count(1)
                        for i in range(n):
                                nbr_pawn2 += board[i].count(2)

                        display(board, n, p)
                        print("")

                if player == 1 :
                        print("IA:")
                        x, y = selectPawnIA(board, n, p, player)
                        a, b, x, y = whereIA(board, n, p, player, x, y)

                        board[a-1][b-1] = 2
                        board[x-1][y-1] = 0

                        for i in range(n):
                                nbr_pawn1 += board[i].count(1)
                        for i in range(n):
                                nbr_pawn2 += board[i].count(2)

                        display(board, n, p)
                        print("")

                winnerIA(board, nbr_pawn1, nbr_pawn2)
                player = change_player(player)

def breaktrough(n, p):
        board = newBoard(n, p)
        display(board, n, p)
        print("")
        nbr_pawn1 = 0
        nbr_pawn2 = 0
        for i in range(n):
                nbr_pawn1 += board[i].count(1)
        for i in range(n):
                nbr_pawn2 += board[i].count(2)
        player = 0
        i = 0
        
        while board[0].count(2) == 0  and board[n-1].count(1) == 0 and nbr_pawn1 != 0 and nbr_pawn2 != 0:
                print("Joueur", player+1, ":")
                x, y = selectPawn(board, n, p, player)

                if player == 0:
                        if y > 1 and y < p and x < n:
                                while board[x][y-2] == 1 and board[x][y-1] != 0 and board[x][y] == 1:
                                        print("Selon les règles du jeu, ce pion ne peut pas se déplacer. Veuillez en choisir un autre .")
                                        x, y = selectPawn(board, n, p, player)

                        if y == 1 and x < n:
                                while board[x][y-1] != 0 and board[x][y] == 1:
                                        print("Selon les règles du jeu, ce pion ne peut pas se déplacer. Veuillez en choisir un autre .")
                                        x, y = selectPawn(board, n, p, player)

                        if y == p and x < n:
                                while board[x][y-2] == 1 and board[x][y-1] != 0:
                                        print("Selon les règles du jeu, ce pion ne peut pas se déplacer. Veuillez en choisir un autre .")
                                        x, y = selectPawn(board, n, p, player)

                if player == 1:
                        if y > 1 and y < p and x > 1:
                                while board[x-2][y-2] == 2 and board[x-2][y-1] != 0 and board[x-2][y] == 2:
                                        print("Selon les règles du jeu, ce pion ne peut pas se déplacer. Veuillez en choisir un autre .")
                                        x, y = selectPawn(board, n, p, player)

                        if y == 1 and x > 1:
                                while board[x-2][y-1] != 0 and board[x-2][y] == 2:
                                        print("Selon les règles du jeu, ce pion ne peut pas se déplacer. Veuillez en choisir un autre .")
                                        x, y = selectPawn(board, n, p, player)

                        if y == p and x > 1:
                                while board[x-2][y-2] == 2 and board[x-2][y-1] != 0:
                                        print("Selon les règles du jeu, ce pion ne peut pas se déplacer. Veuillez en choisir un autre .")
                                        x, y = selectPawn(board, n, p, player)
                
                a, b = where(board, n, p, player, x, y)

                if player == 0 :
                        board[a-1][b-1] = 1
                        board[x-1][y-1] = 0
                if player == 1 :
                        board[a-1][b-1] = 2
                        board[x-1][y-1] = 0

                for i in range(n):
                        nbr_pawn1 += board[i].count(1)
                for i in range(n):
                        nbr_pawn2 += board[i].count(2)

                display(board, n, p)
                print("")
                winner(board, nbr_pawn1, nbr_pawn2)
                player = change_player(player)
        
m = int(input("Joueur 1 vs Joueur 2 (1) ou Joueur 1 vs IA (2) ? : "))

while m != 1 and m !=2 :
       m = int(input("Joueur 1 vs Joueur 2 (1) ou Joueur 1 vs IA (2) ? : "))

n = int(input("Entrez le nombre de lignes du tableau : "))

while n < 4 :
    print("Le tableau doit avoir au moins 5 lignes !")
    n = int(input("Entrez le nombre de lignes du tableau : "))

p = int(input("Entrez le nombre de colonnes du tableau : "))

while p <= 1 :
    print("Le tableau doit avoir au moins 2 colonnes !") 
    p = int(input("Entrez le nombre de colonnes du tableau : "))

print("")

if m == 1:
    breaktrough(n, p)
else :
    breaktroughIA(n, p)

#By Landry Kengni (id: 222410)
