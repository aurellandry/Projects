Username: "root"
Password: "root"

Username: "student"
Password: "azerty"

Username: "fullprof"
Password: "fullpass"


"settings.xml" permet de modifier les informations de connexion à la base de données