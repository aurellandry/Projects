
public class Main {

    public static void main(String[] args) {

        GenericQuery genericQuery = new GenericQuery();

        LoginFrame loginFrame = new LoginFrame(350, 165, "SupNews - Login", genericQuery);
        loginFrame.setVisible(true);

        while (!loginFrame.logged) {
            try {
                Thread.sleep(500);
            } catch (InterruptedException ignore) {}
        }
        loginFrame.setVisible(false);

        String username = loginFrame.getUser();
        DashboardFrame dashboardFrame = new DashboardFrame(700, 500, "SupNews - " + username, username, genericQuery);
        dashboardFrame.setVisible(true);
    }
}
