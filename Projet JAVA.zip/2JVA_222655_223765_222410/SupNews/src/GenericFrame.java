import javax.swing.*;

public class GenericFrame extends JFrame {

    public GenericFrame() {
        this(300, 200);
    }

    public GenericFrame(int width, int height) {
        this(width, height, null);
    }

    public GenericFrame(int width, int height, String title) {
        this.setSize(width, height);
        this.setTitle(title);
        this.setResizable(false);
        this.setVisible(false);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
