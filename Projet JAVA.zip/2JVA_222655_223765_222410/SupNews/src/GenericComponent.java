import javax.swing.*;
import java.awt.*;

class GenericComponent {
    protected static JLabel LabelComponent(String texte, int x, int y) {
        JLabel label = new JLabel(texte);
        Dimension labelSize = label.getPreferredSize();
        label.setBounds(x, y, labelSize.width, labelSize.height);
        return label;
    }

    protected static JTextField TextFieldComponent(int col, int x, int y) {
        JTextField field = new JTextField(col);
        Dimension fieldSize = field.getPreferredSize();
        field.setBounds(x, y, fieldSize.width, fieldSize.height);
        return field;
    }

    protected static JPasswordField PasswordFieldComponent(int col, int x, int y) {
        JPasswordField passwordField = new JPasswordField(col);
        Dimension passwordFieldSize = passwordField.getPreferredSize();
        passwordField.setBounds(x, y, passwordFieldSize.width, passwordFieldSize.height);
        return passwordField;
    }

    protected static JList ListComponent(int x, int y, int w, int h) {
        JList list = new JList();
        list.setBounds(x, y, w, h);
        return list;
    }

    protected static JButton ButtonComponent(String texte, int x, int y) {
        JButton button = new JButton(texte);
        Dimension buttonSize = button.getPreferredSize();
        button.setBounds(x, y, buttonSize.width, buttonSize.height);
        return button;
    }

    protected static JTextArea TextAreaComponent(int rows, int cols, int x, int y) {
        JTextArea textArea = new JTextArea();
        //JScrollPane scrollPane = new JScrollPane(textArea, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        textArea.setRows(rows);
        textArea.setColumns(cols);
        textArea.setLineWrap(true);
        textArea.setBounds(x, y, textArea.getPreferredSize().width, textArea.getPreferredSize().height);
        return textArea;
    }
}
