import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.Properties;
import java.io.FileInputStream;


public class GenericQuery {
    private Connection conn = null;

    GenericQuery() {
        // Load Settings
        Properties loadProps = new Properties();
        try {
            loadProps.loadFromXML(new FileInputStream("settings.xml"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        String hostname = loadProps.getProperty("hostname");
        String port = loadProps.getProperty("port");
        String databaseName = loadProps.getProperty("databaseName");
        String user = loadProps.getProperty("user");
        String password = loadProps.getProperty("password");

        String url = "jdbc:mysql://" + hostname + ":" + port + "/" + databaseName;

        try {
            Class.forName(
                    com.mysql.jdbc.Driver.class.getName());
        } catch (ClassNotFoundException ex) {
            System.out.println("Can’t load the Driver : " + ex);
        }

        try {
            conn = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            System.out.println("Can't connect to DataBase : " + e);
        }
    }

    public String queryToDb(String command, String column) {
        try {
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(command);

            rs.next();
            return rs.getString(column);

        } catch (SQLException e) {
            return null;
        }
    }

    public String[] displayTitleArticles(String username) {
        try {
            PreparedStatement rq = conn.prepareStatement("SELECT title FROM articles WHERE author = '" + username + "' ORDER BY articles.date ASC ");
            ResultSet rs = rq.executeQuery();

            //On récupère les données dans un ArrayList pour éviter les soucis de taille de la liste
            ArrayList<String> array = new ArrayList<String>();
            while (rs.next()) {
                array.add(rs.getString("title"));
            }

            // On crée le tableau qui va contenir les valeurs qu'on va mettre dans la JList
            String[] str = new String[array.size()];

            // On remplit le tableau
            for (int i = 0; i < array.size(); i++) {
                str[i] = array.get(i);
            }
            return str;

        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    public void deleteArticle(String command) {
        try {
            PreparedStatement rq = conn.prepareStatement(command);
            rq.executeUpdate();
        } catch (SQLException ignore) {
        }
    }

    public void saveArticle(String command) {
        try {
            PreparedStatement ps = conn.prepareStatement(command);
            ps.executeUpdate();
        } catch (SQLException ignore) {

        }
    }

    public void saveImage(String name, File myImage, FileInputStream inputStreamImage) {
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO images (name, img) VALUES(?, ?) ON DUPLICATE KEY UPDATE img=VALUES(img)");
            ps.setString(1, name);
            ps.setBinaryStream(2, inputStreamImage, (int) myImage.length());
            ps.executeUpdate();
        } catch (SQLException error1) {
            System.out.println(error1);
        }
    }

    public InputStream loadImage(String name) {
        try {
            Blob blob = null;

            PreparedStatement ps = conn.prepareStatement("SELECT img FROM images WHERE name='"+ name +"'");
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                blob = rs.getBlob("img");
            }

            InputStream istreamImage = blob.getBinaryStream();

            return istreamImage;

        } catch (SQLException ignore) {
            return null;
        }
    }
}
