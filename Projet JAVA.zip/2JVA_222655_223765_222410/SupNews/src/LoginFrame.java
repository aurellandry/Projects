import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.MessageDigest;

public class LoginFrame extends GenericFrame implements ActionListener {

    public boolean logged = false;

    private GenericQuery genericQuery;

    private String generatedPassword;

    public JTextField userf;
    public JTextField passf;

    private JPanel panel;
    private JLabel errorLabel;

    LoginFrame(int width, int height, String title, GenericQuery queryObject) {
        super(width, height, title);

        genericQuery = queryObject;

        panel = new JPanel();
        panel.setLayout(null);

        JLabel userLabel = GenericComponent.LabelComponent("Username :", 58, 30);
        panel.add(userLabel);

        JTextField userField = GenericComponent.TextFieldComponent(7, 140, 27);
        userField.setDocument(new JTextFieldLimit(16));
        panel.add(userField);
        userf = userField;

        JLabel passLabel = GenericComponent.LabelComponent("Password :", 60, 70);
        panel.add(passLabel);

        JPasswordField passField = GenericComponent.PasswordFieldComponent(7, 140, 67);
        passField.setDocument(new JTextFieldLimit(16));
        panel.add(passField);
        passf = passField;

        JButton logButton = GenericComponent.ButtonComponent("Login", 250, 95);
        panel.add(logButton);
        logButton.addActionListener(this);

        errorLabel = GenericComponent.LabelComponent("Username or password incorrect", 20, 110);
        errorLabel.setForeground(Color.RED);

        this.setContentPane(panel);
    }

    public String getUser() {
        return this.userf.getText();
    }

    // Cryptage du mot de passe
    public String getMD5(String motDePasse){
        try {
            byte[] byteMDP = motDePasse.getBytes();
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(byteMDP);
            byte[] hashMDP = md.digest();

            StringBuilder sb = new StringBuilder();
            for(int i=0; i< hashMDP.length ;i++)
            {
                sb.append(Integer.toString((hashMDP[i] & 0xff) + 0x100, 16).substring(1));
            }

            generatedPassword = sb.toString();
            return generatedPassword;

        } catch (Exception e){
            System.out.println(e);
            return null;
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String password = getMD5(passf.getText());
        String result = genericQuery.queryToDb("SELECT `password` FROM `users` WHERE `login` = '" + userf.getText() + "'", "password");

        try {
            if (password.equals(result)) {
                logged = true;
            } else {
                panel.add(errorLabel);
                this.setContentPane(panel);
            }
        } catch (NullPointerException ignore) {}
    }
}
