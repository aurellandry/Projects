import java.awt.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import javax.swing.*;
import javax.swing.text.*;


public class PreviewFrame {

    private GenericQuery genericQuery;

    private StyledDocument doc;
    private SimpleAttributeSet style_normal;
    private SimpleAttributeSet style_titre;
    private SimpleAttributeSet style_bold;
    private SimpleAttributeSet style_itl;
    private SimpleAttributeSet style_undL;
    private SimpleAttributeSet style_boIt;
    private SimpleAttributeSet style_boUn;
    private SimpleAttributeSet style_itUn;
    private SimpleAttributeSet style_left;
    private SimpleAttributeSet style_center;
    private SimpleAttributeSet style_right;
    private SimpleAttributeSet imgempty;
    private HashMap<String, SimpleAttributeSet> dico_style;
    private Style imageStyle;

    PreviewFrame(GenericQuery queryObject) {
        genericQuery = queryObject;
    }


    public void preview(String title, String author, String text) {
        JTextPane textPane = new JTextPane();
        doc = textPane.getStyledDocument();
        style();

        dico_style = new HashMap<>();
        dico_style.put("b", style_bold);
        dico_style.put("i", style_itl);
        dico_style.put("u", style_undL);
        dico_style.put("bi", style_boIt);
        dico_style.put("bu", style_boUn);
        dico_style.put("iu", style_itUn);
        dico_style.put("left", style_left);
        dico_style.put("center", style_center);
        dico_style.put("right", style_right);
        dico_style.put("img", imgempty);

        /*
         * Création du style qui permet d'preview les référénces
         */
        SimpleAttributeSet style_citation = new SimpleAttributeSet();
        style_citation.addAttributes(style_normal);
        StyleConstants.setItalic(style_citation, true);

        try {
            doc.insertString(doc.getLength(), title + "\n\n", style_titre);
            int end_title = doc.getLength();

            parser(text);

            doc.insertString(doc.getLength(), "\n\n\n", style_normal);

            int end_text = doc.getLength();
            doc.insertString(doc.getLength(), author + "     \n", style_citation);

            /*
            * Alignement des paragraphes
            */
            doc.setParagraphAttributes(0, end_title, style_center, false);

            doc.setParagraphAttributes(end_title, end_text, style_left, false);

            doc.setParagraphAttributes(end_text, doc.getLength(), style_right, false);

        } catch (BadLocationException e) {
            e.printStackTrace();
        }

        /*
         * Construction de la fenêtre pour affichage du JTextPane
         */
        JFrame f = new JFrame("Preview - " + title);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setSize(500, 500);
        f.setLocationRelativeTo(null);
        f.setResizable(false);
        textPane.setEditable(false);

        JScrollPane jsp = new JScrollPane(textPane);
        f.setContentPane(jsp);
        f.setVisible(true);
    }

    private void parser(String text) {
        SimpleAttributeSet style = style_normal;
        StyleContext context = new StyleContext();

        try {
            while (true) {
                int pos1 = text.indexOf("{", 0);
                int pos2 = text.indexOf("}", pos1);

                if (pos1 < 0 || pos2 < 0) { break; }

                String sub1 = text.substring(pos1 + 1, pos2);
                style = dico_style.get(sub1);

                int pos3 = text.indexOf("{/" + sub1 + "}", pos2);

                int pos4 = text.indexOf("{", pos2);

                if (pos4 < pos3) {
                    int pos5 = text.indexOf("}", pos4);
                    String type = text.substring(pos4 + 1, pos5);
                    int pos6 = text.indexOf("{/" + type + "}", pos5);

                    String code3 = "";
                    String code4 = "";
                    if ((sub1 + type).equals("bi") || (sub1 + type).equals("ib")) {
                        code3 = "{bi}";
                        code4 = "{/bi}";
                    } else if ((sub1 + type).equals("bu") || (sub1 + type).equals("ub")) {
                        code3 = "{bu}";
                        code4 = "{/bu}";
                    } else if ((sub1 + type).equals("iu") || (sub1 + type).equals("ui")) {
                        code3 = "{iu}";
                        code4 = "{/iu}";
                    }

                    String code = "{/" + sub1 + "}";
                    String code2 = "{" + sub1 + "}";

                    String tempSub = text.substring(0, pos1);
                    doc.insertString(doc.getLength(), tempSub, style_normal);

                    String miss = text.substring(pos4 + type.length() + 2, pos6);

                    text = text.substring(pos1, pos4) + code + code3 + miss + code4 + code2 + text.substring(pos6 + type.length() + 3, pos3 + sub1.length() + 3) + text.substring(pos3 + sub1.length() + 3);
                    continue;
                }

                if (pos3 < 0) {
                    String tempSub = text.substring(0, pos2 + 1);
                    doc.insertString(doc.getLength(), tempSub, style_normal);
                    text = text.substring(pos2 + 1);
                } else {
                    String sub2 = text.substring(pos2 + 1, pos3);

                    String text1 = text.substring(0, pos1);
                    text = text.substring(pos3 + sub1.length() + 3);

                    doc.insertString(doc.getLength(), text1, style_normal);

                    if (style == imgempty){
                        loadImageToDb(sub2);
                        imageStyle = context.getStyle(StyleContext.DEFAULT_STYLE);
                        String sub0= "./img/";
                        sub0=sub0+sub2;
                        ImageIcon icon = new ImageIcon(new ImageIcon(sub0).getImage().getScaledInstance(150, 150, Image.SCALE_DEFAULT));
                        JLabel label = new JLabel(icon);
                        StyleConstants.setComponent(imageStyle, label);
                        doc.insertString(doc.getLength(), "Ignored", imageStyle);
                        new File(sub0).delete();
                    }
                    else {
                        doc.insertString(doc.getLength(), sub2, style);
                    }
                }
            }
            doc.insertString(doc.getLength(), text, style_normal);

        } catch (Exception e){
            System.out.println("ERROR PARSING : " + e);
        }
    }

    private void style() {
        style_normal = new SimpleAttributeSet();
        StyleConstants.setFontFamily(style_normal, "Calibri");
        StyleConstants.setFontSize(style_normal, 14);


        style_titre = new SimpleAttributeSet();
        style_titre.addAttributes(style_normal);
        StyleConstants.setForeground(style_titre, Color.RED);
        StyleConstants.setUnderline(style_titre, true);
        StyleConstants.setFontSize(style_titre, 25);
        StyleConstants.setBold(style_titre, true);


        style_bold = new SimpleAttributeSet();
        style_bold.addAttributes(style_normal);
        StyleConstants.setBold(style_bold, true);

        style_itl = new SimpleAttributeSet();
        style_itl.addAttributes(style_normal);
        StyleConstants.setItalic(style_itl, true);

        style_undL = new SimpleAttributeSet();
        style_undL.addAttributes(style_normal);
        StyleConstants.setUnderline(style_undL, true);

        style_boIt = new SimpleAttributeSet();
        style_boIt.addAttributes(style_normal);
        StyleConstants.setBold(style_boIt, true);
        StyleConstants.setItalic(style_boIt, true);

        style_boUn = new SimpleAttributeSet();
        style_boUn.addAttributes(style_normal);
        StyleConstants.setBold(style_boUn, true);
        StyleConstants.setUnderline(style_boUn, true);

        style_itUn = new SimpleAttributeSet();
        style_itUn.addAttributes(style_normal);
        StyleConstants.setItalic(style_itUn, true);
        StyleConstants.setUnderline(style_itUn, true);


        style_left = new SimpleAttributeSet();
        style_left.addAttributes(style_normal);
        StyleConstants.setAlignment(style_left, StyleConstants.ALIGN_LEFT);

        style_center = new SimpleAttributeSet();
        style_center.addAttributes(style_normal);
        StyleConstants.setAlignment(style_center, StyleConstants.ALIGN_CENTER);

        style_right = new SimpleAttributeSet();
        style_right.addAttributes(style_normal);
        StyleConstants.setAlignment(style_right, StyleConstants.ALIGN_RIGHT);
    }


    // Fonction qui permet de charger l'image depuis la BD
    public void loadImageToDb(String name)
    {
        try {
            FileOutputStream ostreamImage = null;

            InputStream istreamImage = genericQuery.loadImage(name);
            ostreamImage = new FileOutputStream("./img/"+name);

            byte[] buffer = new byte[1024];
            int length = 0;

            while((length = istreamImage.read(buffer)) != -1)
            {
                ostreamImage.write(buffer, 0, length);
            }
        } catch (IOException error2){
            System.out.println(error2);
        }
    }
}
