import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;


public class DashboardFrame extends GenericFrame {

    private GenericQuery genericQuery;

    private JTextField titlefield;
    private String oldTitleField;
    private JTextArea articlearea;
    private JList yourarticles;

    private String username;

    private String selectedArticle = null;

    DashboardFrame(int width, int height, String title, String user, GenericQuery queryObject) {
        super(width, height, title);

        username = user;

        genericQuery = queryObject;


        JPanel panel = new JPanel();
        panel.setLayout(null);

        /* Your articles */
        JLabel yourLabel = GenericComponent.LabelComponent("Your articles", 60, 30);
        panel.add(yourLabel);


        yourarticles = GenericComponent.ListComponent(35, 60, 220, 220);
        yourarticles.setListData(genericQuery.displayTitleArticles(username));
        yourarticles.addListSelectionListener(new ListAction());
        panel.add(yourarticles);


        JButton newButton = GenericComponent.ButtonComponent("New", 50, 400);
        panel.add(newButton);
        newButton.addActionListener(new NewButtonAction());


        JButton deleteButton = GenericComponent.ButtonComponent("Delete", 150, 400);
        panel.add(deleteButton);
        deleteButton.addActionListener(new DeleteButtonListener());


        /* New article */
        JLabel articleLabel = GenericComponent.LabelComponent("New article", 300, 30);
        panel.add(articleLabel);

        JLabel titleLabel = GenericComponent.LabelComponent("Title : ", 300, 60);
        panel.add(titleLabel);

        JTextField titleField = GenericComponent.TextFieldComponent(20, 350, 57);
        titleField.setDocument(new JTextFieldLimit(32));
        panel.add(titleField);
        titlefield = titleField;

        JTextArea articleArea = GenericComponent.TextAreaComponent(15, 30, 0, 0);
        JScrollPane jsp = new JScrollPane(articleArea);
        jsp.setBounds(300,100,365,250);
        articlearea = articleArea;
        panel.add(jsp);

        JButton addImageButton = GenericComponent.ButtonComponent("Add image...", 300, 400);
        panel.add(addImageButton);
        addImageButton.addActionListener(new addImageButtonAction());

        JButton previewButton = GenericComponent.ButtonComponent("Preview", 450, 400);
        panel.add(previewButton);
        previewButton.addActionListener(new PreviewButtonAction());

        JButton saveButton = GenericComponent.ButtonComponent("Save", 550, 400);
        panel.add(saveButton);
        saveButton.addActionListener(new SaveButtonAction());

        this.setContentPane(panel);
    }


    public class NewButtonAction implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            yourarticles.clearSelection();
            titlefield.setText("");
            articlearea.setText("");
            oldTitleField = null;
        }
    }

    public class DeleteButtonListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            genericQuery.deleteArticle("DELETE FROM articles WHERE author='"+ username +"' AND title = '" + selectedArticle + "'");

            //On vide tous les champs de saisie et on met à jour la liste des articles
            yourarticles.setListData(genericQuery.displayTitleArticles(username));
            titlefield.setText("");
            articlearea.setText("");
        }
    }

    public class PreviewButtonAction implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            PreviewFrame previewFrame = new PreviewFrame(genericQuery);
            previewFrame.preview(titlefield.getText(), username, articlearea.getText());
        }
    }

    public class SaveButtonAction implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String command;
            String secondCheck = "SELECT title FROM articles WHERE author = '" + username + "' AND title='"+ titlefield.getText() +"'";
            String secondOldTitle = genericQuery.queryToDb(secondCheck, "title");

            // On vérifiera aussi si l'utilisateur rentre au moins une lettre avec trim (qui retourne un String sans les espaces)
            if (oldTitleField == null) {
                if (secondOldTitle == null && !(titlefield.getText().trim().equals(""))) {
                    command = "INSERT INTO articles(author, date, title, text) VALUES ('"+ username +"', CURRENT_TIMESTAMP, '"+ titlefield.getText() +"', '"+ articlearea.getText() +"')";
                } else {
                    return;
                }
            } else {
                if ((secondOldTitle == null && !(titlefield.getText().trim().equals(""))) || (secondOldTitle != null && oldTitleField.equals(titlefield.getText()))) {
                    command = "UPDATE articles SET date=CURRENT_TIMESTAMP, title='"+ titlefield.getText() +"', text='" + articlearea.getText() + "' WHERE author='" + username + "' AND title='" + oldTitleField + "'";
                } else {
                    return;
                }
            }
            genericQuery.saveArticle(command);
            yourarticles.setListData(genericQuery.displayTitleArticles(username));
            titlefield.setText("");
            articlearea.setText("");
            }
    }

    public class ListAction implements ListSelectionListener {
        public void valueChanged(ListSelectionEvent e) {
            selectedArticle = ""+yourarticles.getSelectedValue();

            String result = genericQuery.queryToDb("SELECT text FROM articles WHERE author='"+ username +"' AND title='"+ yourarticles.getSelectedValue() +"'", "text");
            articlearea.setText(result);
            titlefield.setText(selectedArticle);

            oldTitleField = selectedArticle;
        }
    }

    public class addImageButtonAction implements ActionListener {
        public void actionPerformed(ActionEvent e){
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileFilter(new FileNameExtensionFilter("Images", "jpg", "jpeg", "png", "gif"));
            String filePath = "";
            String fileName = "";
            String updateArticle = articlearea.getText();
            int returnValue = fileChooser.showOpenDialog(null);

            if (returnValue == JFileChooser.APPROVE_OPTION){
                filePath = fileChooser.getSelectedFile().getAbsolutePath();
                fileName = fileChooser.getSelectedFile().getName();
            }

            if (!fileName.equals("")) {
                updateArticle += "{img}"+fileName+"{/img}";
                articlearea.setText(updateArticle);
                saveImageToDb(filePath, fileName);
            }
        }
    }

    public void saveImageToDb(String location, String name)
    {
        try {
            File monImage = new File(location);
            FileInputStream inputStreamImage = new FileInputStream(monImage);

            try
            {
                genericQuery.saveImage(name, monImage, inputStreamImage);
            } catch (Exception error2){
                System.out.println(error2);
            }
            finally
            {
                inputStreamImage.close();
            }
        } catch (Exception error3){
            System.out.println(error3);
        }
    }

}
