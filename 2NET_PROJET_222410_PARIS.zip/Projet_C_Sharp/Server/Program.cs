﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Server
{
    class Program
    {

        private static Thread Ecoute;
        //private static Thread AfficheMenu;
        static string globalMessage = "";
        static string combinaison;
        //static byte[] msg = null;
        //static UdpClient serveur = new UdpClient(5035);

        static void Main(string[] args)
        {

            Ecoute = new Thread(new ThreadStart(Ecouter));
            Ecoute.Start();

        }



        private static void Ecouter()
        {
            UdpClient serveur = new UdpClient(5035);
            //string indication = "";
            int a = 0;

            while (true)
            {

                string indication = "";
                IPEndPoint msg = null;
                byte[] data2 = null;

                byte[] data = serveur.Receive(ref msg);

                string message_received = Encoding.Default.GetString(data);
                Console.WriteLine("\n {0}", message_received);


                if (a == 0)
                {
                    combinaison = message_received;
                    a = 1;
                }

                else
                {
                    globalMessage = message_received;

                    for (int i = 0; i < globalMessage.Length; i++)
                    {
                        if (globalMessage[i] == combinaison[i])
                        {
                            indication += "N";
                        }
                    }

                    for (int i = 0; i < globalMessage.Length; i++)
                    {
                        int d = i;
                        for (int j = 0; j < combinaison.Length; j++)
                        {
                            //Console.WriteLine(".");
                            if (combinaison[i] != globalMessage[i] && combinaison[j] == globalMessage[i] && combinaison[j] != globalMessage[j] && i != j)
                            {
                                indication += "B";
                            }

                        }
                    }

                    Console.WriteLine("{0}", indication);
                    data2 = Encoding.Default.GetBytes(indication);
                    //indication = "";
                    serveur.Send(data2, data2.Length, "127.0.0.1", 5034);

                }


            }
        }


    }
}
