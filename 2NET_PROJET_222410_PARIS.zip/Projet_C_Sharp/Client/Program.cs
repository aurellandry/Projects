﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;



namespace Client
{
    class Program
    {

        static Thread Listen;
        static Joueur joueur1;
        static Joueur joueur2;
        static UdpClient client1 = new UdpClient(5036);
        static UdpClient client2 = new UdpClient(5037);
        static string answer;
        static string indicationReceived = "";
        static string combinaison = "";


        static void Main(string[] args)
        {

            Listen = new Thread(new ThreadStart(Listening));
            Listen.Start();

            AfficherMenu();
            Jeu();
            Environment.Exit(-1);

        }



//    ---------------------------------------------------------------------------------------




        static void Listening ()   // Écoute des messages entrants
        {

            UdpClient client = new UdpClient(5034);

            while (true)
            {

                IPEndPoint msg = null;

                byte[] data = client.Receive(ref msg);
                string message = Encoding.Default.GetString(data);
                indicationReceived = message;

                Console.WriteLine("    {0} /", indicationReceived);

            }

        }



//   ----------------------------------------------------------------------------------------





        static void AfficherMenu()
        {
            Console.WriteLine("Menu: \n");
            Console.WriteLine("1- Jouer");
            Console.WriteLine("2- Règles du jeu");
            Console.WriteLine("3- Crédits");
        }





//   ---------------------------------------------------------------------------------------




        static void AfficherReglesDuJeu()
        {
            Console.WriteLine("\n  Pour commencer, il vous faut décider entre vous et votre adversaire " +
                                      "lequel élabore la combinaison secrète. Mettez-vous d’accord sur le " +
                                      "nombre de manche que vous souhaitez disputer afin de vous assurez d’un " +
                                      "gagnant.\n  Le 1er joueur élabore alors sa combinaison de couleur sans " +
                                      "bien entendu la dévoiler à l’autre joueur. Le second peut alors commencer " +
                                      "à faire des propositions de combinaisons. Pour cela il doit insérer 4 pions " +
                                      "dans la première ligne située la plus près de lui.");

            Console.WriteLine("\nSI LA COMBINAISON PRÉSENTÉE EST INCORRECTE: ");

            Console.WriteLine("\n  Le joueur qui a élaboré la combinaison secrète utilise les languettes " +
                              "situé sur les côtés du plateau. Si dans la proposition, un ou plusieurs " +
                              "pions de couleurs sont bien dans la combinaison mais pas à la bonne place, " +
                              "le joueur doit alors tirer la languette blanche (B) selon le nombre.\n  Si " +
                              "dans la proposition, un ou plusieurs pions de couleurs sont bien dans la " +
                              "combinaison et à la bonne place, le joueur doit alors tirer la languette " +
                              "noire (N) selon le nombre.\n  Le joueur devant deviner la combinaison continue " +
                              "ainsi en proposant sur la seconde ligne une autre proposition, en prenant bien " +
                              "entendu en compte les indications des languettes rouges et blanches. Il a " +
                              "droit a 12 propositions maximum pour déchiffrer le code.");

            Console.WriteLine("\nSI LA COMBINAISON EST CORRECTE: ");

            Console.WriteLine("\n  Le joueur qui a élaboré la combinaison secrète révèle le code et la manche " +
                              "est terminée. Les rôles sont alors inversés et la seconde manche peut ainsi " +
                              "commencer.");

            Console.WriteLine("\nCONDITION DE GAGNE: ");

            Console.WriteLine("\n  Le gagnant d’une partie de Mastermind est celui qui a gagné le plus de " +
                              "manches selon le nombre préalablement établis.");
        }





//   ---------------------------------------------------------------------------------------------------------




        static void Jeu()
        {
            bool continuer = true;
            int choice;
            int choiceAttemps;
            int choiceColor;
            string proposition = "";

            while (continuer)
            {

                do
                {
                    Console.Write("\nVotre choix : ");
                    choice = Convert.ToInt32(Console.ReadLine());
                }
                while (choice <= 0 && choice > 3);


                switch (choice)
                {
                    case 1:

                        Console.WriteLine("\nLes couleurs autorisées sont: Bleu (B), Rouge (R), Vert (V), Jaune (J), " +
                                          "\nOrange (O), Gris (G), Indigo (I), Noir(N). Pour donc choisir une " +
                                          "couleur \nil suffit de saisir la lettre qui lui est associée. \nLes " +
                                          "combinaisons seront de la forme 'XXXX' (chaque X représentant une couleur).\n");

                        do
                        {
                            Console.Write("\nCombien de couleurs doit compter la combinaison ? : ");
                            choiceColor = Convert.ToInt32(Console.ReadLine());
                        }
                        while (choiceColor > 8);

                        do
                        {
                            Console.Write("\nCombien de tentatives souhaiter vous effectuer ? (Maximum 12) : ");
                            choiceAttemps = Convert.ToInt32(Console.ReadLine());
                        }
                        while (choiceAttemps > 12);



                        Console.Write("\nJoueur vs Joueur (1) / Joueur vs IA (2) :");
                        int choicePlayer = Convert.ToInt32(Console.ReadLine());
                        if (choicePlayer == 1)
                        {
                            Console.Write("\nPseudo du Joueur 1: ");
                            string pseudo1 = Console.ReadLine();
                            joueur1 = new Joueur(pseudo1, client1);


                            Console.Write("\nPseudo du Joueur 2: ");
                            string pseudo2 = Console.ReadLine();
                            joueur2 = new Joueur(pseudo2, client2);

                            EnvoyerCombinaison(joueur1, choiceColor);

                            int a = 0;
                            int b = choiceAttemps;
                            bool gagne = Winner(proposition, a, b);

                            while (choiceAttemps > 0 && gagne == false)
                            {

                                Console.Write("{0} entrez votre proposition: ", joueur2.GetNom());

                                ConsoleKeyInfo key;

                                do
                                {
                                    key = Console.ReadKey(true);

                                    if (key.Key != ConsoleKey.Backspace && proposition.Length < choiceColor && (key.Key == ConsoleKey.B || key.Key == ConsoleKey.R || key.Key == ConsoleKey.V || key.Key == ConsoleKey.J || key.Key == ConsoleKey.O || key.Key == ConsoleKey.G))
                                    {
                                        proposition += key.KeyChar;
                                        Console.Write("{0}", key.KeyChar);
                                    }
                                    else
                                    {
                                        Console.Write("");
                                    }
                                }

                                while (key.Key != ConsoleKey.Enter);



                                joueur2.EnvoyerMessage(proposition, client2);


                                while (indicationReceived.Length == 0)
                                {
                                    continue;
                                }

                                Console.WriteLine("\n Indications : {0} ('N' pour Noir et 'B' pour Blanc).", indicationReceived);

                                choiceAttemps -= 1;
                                a += 1;
                                gagne = Winner(proposition, a, b);
                                proposition = "";

                            }

                            if (gagne == true)
                            {
                                Console.WriteLine("\n{0} remporte la partie !", joueur2.GetNom());
                            }
                            else
                            {
                                Console.WriteLine("\n{0} remporte la partie !", joueur1.GetNom());
                            }


                        }


                        // <--- Partie IA --->

                        else if (choicePlayer == 2)
                        {

                            joueur1 = new Joueur("IA", client1);
                            
                            Console.Write("\nEntrez votre pseudo: ");
                            string pseudo = Console.ReadLine();
                            joueur2 = new Joueur(pseudo, client2);

                            EnvoyerCombinaisonIA(joueur1, choiceColor);

                            int a = 0;
                            int b = choiceAttemps;
                            bool gagne = Winner(proposition, a, b);

                            while (choiceAttemps > 0 && gagne == false)
                            {

                                Console.Write("{0} entrez votre proposition: ", joueur2.GetNom());

                                ConsoleKeyInfo key;

                                do
                                {
                                    key = Console.ReadKey(true);

                                    if (key.Key != ConsoleKey.Backspace && proposition.Length < choiceColor && (key.Key == ConsoleKey.B || key.Key == ConsoleKey.R || key.Key == ConsoleKey.V || key.Key == ConsoleKey.J || key.Key == ConsoleKey.O || key.Key == ConsoleKey.G || key.Key == ConsoleKey.I || key.Key == ConsoleKey.N))
                                    {
                                        proposition += key.KeyChar;
                                        Console.Write("{0}", key.KeyChar);
                                    }
                                    else
                                    {
                                        Console.Write("");
                                    }
                                }

                                while (key.Key != ConsoleKey.Enter);



                                joueur2.EnvoyerMessage(proposition, client2);


                                while (indicationReceived.Length == 0)
                                {
                                    continue;
                                }

                                Console.WriteLine("\n Indications : {0} ('N' pour Noir et 'B' pour Blanc).", indicationReceived);

                                choiceAttemps -= 1;
                                a += 1;
                                gagne = Winner(proposition, a, b);
                                proposition = "";
                                indicationReceived = "";

                            }

                            if (gagne == true)
                            {
                                Console.WriteLine("\n{0} remporte la partie !", joueur2.GetNom());
                            }
                            else
                            {
                                Console.WriteLine("\n{0} remporte la partie !", joueur1.GetNom());
                            }

                        }

                        //   <--- Fin partie IA --->

                        Console.Write("\nVoulez-vous retourner au menu ? (O/N): ");
                        answer = Console.ReadLine();
                        if (answer == "O")
                        {
                            Console.WriteLine();
                            AfficherMenu();
                            continue;
                        }
                        else if (answer == "N")
                        {
                            continuer = false;
                        }

                        break;

                    case 2:     //Règles du Jeu
                        AfficherReglesDuJeu();

                        Console.Write("\nVoulez-vous retourner au menu ? (O/N): ");
                        answer = Console.ReadLine();
                        if (answer == "O")
                        {
                            Console.WriteLine();
                            AfficherMenu();
                            continue;
                        }
                        else if (answer == "N")
                        {
                            continuer = false;
                        }

                        break;

                    case 3:
                        Console.WriteLine("Jeu développé par Aurel Landry KENGNI NKONGTCHOU, élève en 2ème année à " +
                                          "SUPINFO Paris.\n Copyright (c) 2018.");
                        
                        
                        Console.Write("\nVoulez-vous retourner au menu ? (O/N): ");
                        answer = Console.ReadLine();

                        if (answer == "O")
                        {
                            Console.WriteLine();
                            AfficherMenu();
                            continue;
                        }
                        else if (answer == "N")
                        {
                            continuer = false;
                        }

                        break;

                    default:
                        Console.WriteLine("Commande invalide !");

                        Console.Write("\nVoulez-vous retourner au menu ? (O/N): ");
                        answer = Console.ReadLine();

                        if (answer == "O")
                        {
                            Console.WriteLine();
                            AfficherMenu();
                            continue;
                        }
                        else if (answer == "N")
                        {
                            continuer = false;
                        }

                        break;
                }

            }

        }





//     -----------------------------------------------------------------------------------------------------





        static void EnvoyerCombinaison(Joueur player, int couleurs)
        {
            Console.WriteLine("\nVous allez devoir choisir une combinaison secrète d'au maximum {0} couleurs parmi" +
                              " les 8 couleurs disponibles.\nVous avez " +
                                          "le choix entre les différentes couleurs.\n[B: bleu; R: rouge; V: " +
                              "vert; J: jaune; O: Orange; G: Gris; I: Indigo; N: Noir]\n", Convert.ToString(couleurs));

            Console.Write("{0} choisissez votre combinaison : ", player.GetNom());

            ConsoleKeyInfo key;

            do
            {
                key = Console.ReadKey(true);

                // Backspace Should Not Work
                if (key.Key != ConsoleKey.Backspace && combinaison.Length < couleurs && (key.Key == ConsoleKey.B || key.Key == ConsoleKey.R || key.Key == ConsoleKey.V || key.Key == ConsoleKey.J || key.Key == ConsoleKey.O || key.Key == ConsoleKey.G || key.Key == ConsoleKey.I || key.Key == ConsoleKey.N))
                {
                    combinaison += key.KeyChar;
                    Console.Write("*");
                }
                else
                {
                    Console.Write("");
                }
            }
            // Stops Receving Keys Once Enter is Pressed
            while (key.Key != ConsoleKey.Enter);

            player.EnvoyerMessage(combinaison, client1);
            Console.WriteLine("\n{0} a choisi sa combinaison.\n", player.GetNom());
        }



        static bool Winner(string indic, int attemps, int nbrAttemps)
        {

            if (indic == combinaison && attemps <= nbrAttemps )
            {
                return true;

            }
            else
            {
                return false;
                //Console.WriteLine("\n{0} remporte la partie !", player1);
            }

        }



        static void EnvoyerCombinaisonIA(Joueur player, int columns)
        {

            Random index = new Random();
            combinaison = "";

            string[] colors = new string[] { "B", "R", "V", "J", "O", "G", "I", "N" };

            while (columns > 0)
            {
                combinaison += colors[index.Next(8)];
                columns -= 1;
            }

            player.EnvoyerMessage(combinaison, client1);
            Console.WriteLine("\n{0} a choisi sa combinaison.\n", player.GetNom());

        }


    }
}
