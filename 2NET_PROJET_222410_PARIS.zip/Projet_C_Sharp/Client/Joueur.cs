﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Text;


namespace Client
{

    public class Joueur
    {

        private string _nom;
        private readonly UdpClient _joueur;


        public Joueur(string name, UdpClient player)
        {
            _nom = name;
            _joueur = player;
        }


        public string GetNom()
        {
            return _nom;
        }


        public UdpClient GetClient()
        {
            return _joueur;
        }


        public void SetNom(string name)
        {
            _nom = name;
        }


        public void EnvoyerMessage(string message, UdpClient player)
        {
            byte[] msg = Encoding.Default.GetBytes(message);
            player.Send(msg, msg.Length, "127.0.0.1", 5035);
        }



    }

}
